'use client';

// This file is intentionally left blank as Firebase is not being used in this project.
export {};
