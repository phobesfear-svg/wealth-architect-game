import type { JobName, Job, BusinessType, Milestone, RandomEvent, InterviewData, Reward, Asset, Prize } from './types';

export const INITIAL_CASH = 0.0;

export const JOBS: Record<JobName, Job> = {
  "Unemployed": { daily_income: 0, description: "No income — find a job!" },
  "Retail Assistant": { daily_income: 45, description: "Steady but modest income." },
  "Office Clerk": { daily_income: 70, description: "Desk job, decent pay." },
  "Graphic Designer": { daily_income: 95, description: "Create visuals for clients." },
  "Software Dev": { daily_income: 140, description: "High income, high pressure." },
  "Marketing Manager": { daily_income: 180, description: "Lead campaigns and drive growth." },
  "Hedge Fund Analyst": { daily_income: 250, description: "Elite earner. Rare opportunity." },
};

export const DAILY_EXPENSES: Record<string, number> = {
  "Rent": 20,
  "Food": 10,
  "Bills": 5,
};

type BusinessConfig = [number, number, number, string, number]; // startup_cost, base_income, success_chance, risk, supply_cost
export const BUSINESS_TYPES: Record<BusinessType, BusinessConfig> = {
  "Food Stall": [500, 30, 0.70, "Low Risk", 10],
  "Freelance Writer": [200, 25, 0.80, "Low Risk", 5],
  "Online Shop": [800, 55, 0.60, "Medium Risk", 20],
  "Cafe": [2000, 90, 0.55, "Medium Risk", 35],
  "Consultancy": [1500, 120, 0.50, "Medium Risk", 25],
  "Vending Machine Route": [3000, 100, 0.75, "Low Risk", 0],
  "Tech Startup": [5000, 200, 0.35, "High Risk", 70],
  "Property Rental": [8000, 160, 0.65, "Low Risk", 0],
  "Real Estate Agency": [10000, 350, 0.40, "High Risk", 50],
  "AI SaaS Startup": [25000, 800, 0.25, "High Risk", 150],
};

export const BUSINESS_RESOURCE_LABELS: Record<BusinessType, string> = {
  "Food Stall": "Ingredients",
  "Freelance Writer": "Contracts",
  "Online Shop": "Inventory",
  "Cafe": "Supplies",
  "Consultancy": "Clients",
  "Vending Machine Route": "Products",
  "Tech Startup": "Engineers",
  "Property Rental": "Contractors",
  "Real Estate Agency": "Agents",
  "AI SaaS Startup": "AI Engineers",
};

export const BUSINESS_UPGRADES = [
  // Level info - index 0 is Level 1, index 4 is Level 5
  { level: 1, costMultiplier: 0, incomeMultiplier: 1 },
  { level: 2, costMultiplier: 0.75, incomeMultiplier: 1.8 },
  { level: 3, costMultiplier: 2.0, incomeMultiplier: 3.5 },
  { level: 4, costMultiplier: 5.0, incomeMultiplier: 7.0 },
  { level: 5, costMultiplier: 15.0, incomeMultiplier: 15.0 },
];

export const INITIAL_STOCKS: {
  ticker: string;
  name: string;
  price: number;
  volatility: number;
  sector: string;
}[] = [
  { ticker: "NOVA", name: "NovaCore Tech", price: 142.50, volatility: 0.028, sector: "Technology" },
  { ticker: "GLDN", name: "Golden Harvest", price: 58.00, volatility: 0.015, sector: "Agriculture" },
  { ticker: "VRTX", name: "Vortex Energy", price: 94.30, volatility: 0.035, sector: "Energy" },
  { ticker: "BRIX", name: "Brixwell Property", price: 37.80, volatility: 0.012, sector: "Real Estate" },
  { ticker: "AXON", name: "Axon Pharma", price: 211.00, volatility: 0.040, sector: "Healthcare" },
  { ticker: "TIDE", name: "Tidal Finance", price: 76.50, volatility: 0.022, sector: "Finance" },
  { ticker: "CYBR", name: "Cyber Secure", price: 115.70, volatility: 0.038, sector: "Technology" },
  { ticker: "HEAL", name: "HealCo Wellness", price: 88.20, volatility: 0.018, sector: "Healthcare" },
  { ticker: "LUXE", name: "Luxe Retail", price: 45.10, volatility: 0.025, sector: "Retail" },
  { ticker: "GRID", name: "Gridstone Utility", price: 62.90, volatility: 0.009, sector: "Utilities" },
];

export const MILESTONES: Milestone[] = [
  { threshold: 5_000, coins: 50, label: "£5k Club", desc: "You crossed £5,000 net worth!" },
  { threshold: 10_000, coins: 100, label: "Five Figure Hero", desc: "You hit £10,000 net worth!" },
  { threshold: 25_000, coins: 200, label: "Quarter Century", desc: "£25,000 — seriously impressive." },
  { threshold: 50_000, coins: 350, label: "Fifty Large", desc: "£50,000 net worth achieved!" },
  { threshold: 100_000, coins: 500, label: "Six Figure Legend", desc: "You joined the £100k club!" },
  { threshold: 250_000, coins: 750, label: "Quarter Millionaire", desc: "£250,000 — financial freedom close!" },
  { threshold: 500_000, coins: 1000, label: "Half a Mil", desc: "£500,000 net worth. Incredible." },
  { threshold: 1_000_000, coins: 2000, label: "Millionaire!", desc: "£1,000,000 reached. You won!" },
];

export const RANDOM_EVENTS: RandomEvent[] = [
  { name: "Boiler Breakdown", effect: -300, msg: "Emergency boiler repair cost £300." },
  { name: "Birthday Gift", effect: 150, msg: "Relatives sent you a £150 gift!" },
  { name: "Car Tyre Burst", effect: -120, msg: "Tyre blew out — £120 repair." },
  { name: "Freelance Gig", effect: 200, msg: "Quick freelance job earned £200!" },
  { name: "Council Tax Hike", effect: -80, msg: "Council tax hike — pay £80 extra." },
  { name: "Cashback Reward", effect: 60, msg: "Credit card cashback: £60!" },
  { name: "Parking Fine", effect: -50, msg: "£50 parking ticket. Ouch." },
  { name: "Energy Rebate", effect: 90, msg: "Government energy rebate: £90!" },
  { name: "Phone Stolen", effect: -250, msg: "Phone stolen — replace for £250." },
  { name: "Neighbour's Gift", effect: 40, msg: "Neighbour gave you a £40 gift!" },
];

export const JOB_INTERVIEWS: Record<string, InterviewData> = {
    "Retail Assistant": {
        min_cash: 0,
        questions: [
            {"q": "A customer is rude to you. What do you do?", "answers": ["Stay calm and try to help them professionally.", "Tell them to leave immediately.", "Ignore them and serve someone else.", "Argue back to defend yourself."]},
            {"q": "The till is £10 short at end of day. What do you do?", "answers": ["Report it to your manager straight away.", "Put £10 of your own money in to cover it.", "Ignore it — it's only £10.", "Blame a colleague."]},
            {"q": "What does good customer service mean to you?", "answers": ["Making every customer feel valued and helping them efficiently.", "Selling as much as possible to each customer.", "Being friendly only to regular customers.", "Following scripts exactly, no matter what."]},
        ],
    },
    "Office Clerk": {
        min_cash: 200,
        questions: [
            {"q": "Your manager sets a deadline you think is unrealistic. You…", "answers": ["Raise your concerns early and suggest a revised timeline.", "Agree and then miss the deadline.", "Refuse to do the task.", "Say nothing and work overtime without telling anyone."]},
            {"q": "You notice a colleague making a repeated error in reports. You…", "answers": ["Politely let them know and offer to help.", "Report them to HR immediately.", "Correct it yourself without saying anything.", "Leave it — it's not your problem."]},
            {"q": "Which skill is most important for an office clerk?", "answers": ["Spreadsheets and word processing.", "3D modelling software.", "Video editing tools.", "Server administration."]},
        ],
    },
    "Graphic Designer": {
        min_cash: 800,
        questions: [
            {"q": "What is the difference between raster and vector graphics?", "answers": ["Raster is pixel-based, vector is path-based and scalable.", "Raster is for print, vector is for web.", "Vector uses more memory.", "There is no difference."]},
            {"q": "A client dislikes your design but gives vague feedback. You...", "answers": ["Ask targeted questions to understand their needs better.", "Guess what they want and send a new version.", "Tell them the design is good as-is.", "Complain about the client to your boss."]},
            {"q": "Which is NOT a principle of design?", "answers": ["Randomness", "Contrast", "Balance", "Hierarchy"]},
        ],
    },
    "Software Dev": {
        min_cash: 1500,
        questions: [
            {"q": "What does 'debugging' mean?", "answers": ["Finding and fixing errors in code.", "Writing code faster.", "Testing a website's design.", "Deploying an app to production."]},
            {"q": "A client requests a feature that will take 3× longer than budgeted. You…", "answers": ["Communicate the trade-offs clearly and agree on scope.", "Build it anyway and bill later.", "Refuse the feature entirely.", "Outsource it without telling anyone."]},
            {"q": "What is version control used for?", "answers": ["Tracking changes to code over time.", "Controlling the version of Windows.", "Managing software licences.", "Speeding up compile times."]},
        ],
    },
    "Marketing Manager": {
        min_cash: 5000,
        questions: [
            {"q": "What does 'SEO' stand for?", "answers": ["Search Engine Optimization.", "Social Engagement Opportunity.", "Sales-Enabled Organization.", "Secure Enterprise Operations."]},
            {"q": "Your latest campaign has a low ROI. What's your first step?", "answers": ["Analyze the campaign data to identify underperforming areas.", "Immediately cancel the campaign.", "Increase the budget to see if it improves.", "Blame the creative team."]},
            {"q": "What is a key metric for measuring social media engagement?", "answers": ["Interaction rate (likes, comments, shares per follower).", "The number of followers gained.", "The total ad spend.", "The number of posts per day."]},
        ],
    },
    "Hedge Fund Analyst": {
        min_cash: 10000,
        questions: [
            {"q": "What does a P/E ratio measure?", "answers": ["Price per share relative to earnings per share.", "Profit divided by expenses.", "Percentage of equity held by insiders.", "Portfolio efficiency score."]},
            {"q": "What is short selling?", "answers": ["Borrowing shares and selling them, betting the price will fall.", "Selling shares you own quickly.", "Buying shares at a discount.", "Closing a position before maturity."]},
            {"q": "Market volatility spikes. Your fund's response?", "answers": ["Re-evaluate risk exposure and hedge appropriately.", "Sell everything immediately.", "Double down on the highest-risk positions.", "Do nothing — volatility always corrects."]},
        ],
    },
};

export const INTERVIEW_PASS_THRESHOLD: Record<string, number> = {
  "Retail Assistant": 1,
  "Office Clerk": 2,
  "Graphic Designer": 2,
  "Software Dev": 2,
  "Marketing Manager": 2,
  "Hedge Fund Analyst": 3,
};

export const REWARDS: Reward[] = [
    // Wallpapers
    { cost: 750, name: "Cozy Bedroom", type: "wallpaper", desc: "A comfortable space for financial planning.", value: "bedroom", rarity: 'Uncommon' },
    { cost: 1500, name: "Penthouse View", type: "wallpaper", desc: "City view from your penthouse.", value: "penthouse", rarity: 'Uncommon' },
    { cost: 5000, name: "Interstellar", type: "wallpaper", desc: "A view from the edge of the galaxy.", value: "nebula", rarity: 'Legendary' },
    
    // Special Items
    { cost: 9999, name: "Golden Ticket", type: "item", desc: "A super rare item from the prize wheel.", value: "golden_ticket", rarity: 'Legendary' },

    // --- Titles ---

    // Common
    { cost: 25, name: "Newbie", type: "title", desc: "Everyone starts somewhere.", rarity: 'Common' },
    { cost: 25, name: "Aspirant", type: "title", desc: "You have goals.", rarity: 'Common' },
    { cost: 50, name: "Penny Pincher", type: "title", desc: "Every penny counts.", rarity: 'Common' },
    { cost: 50, name: "Beginner Investor", type: "title", desc: "Your first investor title.", rarity: 'Common' },
    { cost: 75, name: "Budget Boss", type: "title", desc: "Master of your money.", rarity: 'Common' },
    { cost: 75, name: "The Regular", type: "title", desc: "You're a familiar face.", rarity: 'Common' },
    { cost: 100, name: "Apprentice", type: "title", desc: "Learning the ropes.", rarity: 'Common' },
    { cost: 100, name: "Hobbyist", type: "title", desc: "In it for the fun.", rarity: 'Common' },
    { cost: 125, name: "Go-Getter", type: "title", desc: "Full of ambition.", rarity: 'Common' },
    { cost: 125, name: "Up-and-Comer", type: "title", desc: "Showing promise.", rarity: 'Common' },

    // Uncommon
    { cost: 150, name: "Entrepreneur", type: "title", desc: "Building your own path.", rarity: 'Uncommon' },
    { cost: 150, name: "Day Trader", type: "title", desc: "Riding the market waves.", rarity: 'Uncommon' },
    { cost: 175, name: "Specialist", type: "title", desc: "An expert in your field.", rarity: 'Uncommon' },
    { cost: 175, name: "Influencer", type: "title", desc: "You have an audience.", rarity: 'Uncommon' },
    { cost: 200, name: "The Professional", type: "title", desc: "Cool, calm, and collected.", rarity: 'Uncommon' },
    { cost: 200, name: "Risk Taker", type: "title", desc: "Fortune favors the bold.", rarity: 'Uncommon' },
    { cost: 250, name: "Tastemaker", type: "title", desc: "You set the trends.", rarity: 'Uncommon' },
    { cost: 250, name: "Trailblazer", type: "title", desc: "Forging new paths.", rarity: 'Uncommon' },
    { cost: 300, name: "High-Flyer", type: "title", desc: "Soaring to new heights.", rarity: 'Uncommon' },
    { cost: 300, name: "Artisan", type: "title", desc: "A master of your craft.", rarity: 'Uncommon' },
    
    // Rare
    { cost: 400, name: "Financier", type: "title", desc: "Making money move.", rarity: 'Rare' },
    { cost: 400, name: "Mogul", type: "title", desc: "Building an empire.", rarity: 'Rare' },
    { cost: 500, name: "Magnate", type: "title", desc: "A person of influence.", rarity: 'Rare' },
    { cost: 500, name: "Collector", type: "title", desc: "Curating the finest assets.", rarity: 'Rare' },
    { cost: 600, name: "The Connoisseur", type: "title", desc: "You have refined taste.", rarity: 'Rare' },
    { cost: 600, name: "Visionary", type: "title", desc: "Seeing the future of finance.", rarity: 'Rare' },
    { cost: 700, name: "Socialite", type: "title", desc: "The life of the party.", rarity: 'Rare' },
    { cost: 700, name: "Power Broker", type: "title", desc: "You make the deals.", rarity: 'Rare' },
    { cost: 800, name: "Tycoon", type: "title", desc: "A leader of industry.", rarity: 'Rare' },
    { cost: 800, name: "Virtuoso", type: "title", desc: "Performing with technical brilliance.", rarity: 'Rare' },
    
    // Epic
    { cost: 1000, name: "Titan of Industry", type: "title", desc: "Your name is whispered with respect.", rarity: 'Epic' },
    { cost: 1000, name: "Market Maestro", type: "title", desc: "Conducting the orchestra of the economy.", rarity: 'Epic' },
    { cost: 1250, name: "The High Roller", type: "title", desc: "Big risks, bigger rewards.", rarity: 'Epic' },
    { cost: 1250, name: "Philanthropist", type: "title", desc: "Giving back in a big way.", rarity: 'Epic' },
    { cost: 1500, name: "Kingmaker", type: "title", desc: "Your influence shapes the world.", rarity: 'Epic' },
    { cost: 1500, name: "World-Shaker", type: "title", desc: "Your actions have global impact.", rarity: 'Epic' },
    { cost: 1750, name: "The Vanguard", type: "title", desc: "At the forefront of everything.", rarity: 'Epic' },
    { cost: 1750, name: "Rainmaker", type: "title", desc: "You make the impossible happen.", rarity: 'Epic' },
    { cost: 2000, name: "Wolf of the Exchange", type: "title", desc: "Prestigious elite title.", rarity: 'Epic' },
    { cost: 2000, name: "Shadow Broker", type: "title", desc: "Moving unseen, shaping all.", rarity: 'Epic' },

    // Legendary
    { cost: 2500, name: "Oracle of Wealth", type: "title", desc: "You don't predict the future, you own it.", rarity: 'Legendary' },
    { cost: 3000, name: "Architect of Fate", type: "title", desc: "The designer of destiny.", rarity: 'Legendary' },
    { cost: 3500, name: "Galactic Overlord", type: "title", desc: "Why stop at one world?", rarity: 'Legendary' },
    { cost: 4000, name: "The Ascended", type: "title", desc: "You've transcended mere wealth.", rarity: 'Legendary' },
    { cost: 5000, name: "Living Myth", type: "title", desc: "Your story is told in hushed tones.", rarity: 'Legendary' },
];

export const ASSETS: Asset[] = [
  { name: "Designer Watch", cost: 20000, type: 'Luxury Good' },
  { name: "Sports Car", cost: 150000, type: 'Vehicle' },
  { name: "Luxury Apartment", cost: 500000, type: 'Property' },
  { name: "Art Collection", cost: 1200000, type: 'Luxury Good'},
  { name: "Private Yacht", cost: 5000000, type: 'Vehicle' },
  { name: "Private Jet", cost: 20000000, type: 'Vehicle' },
];

export const PRIZE_WHEEL_COST = 5;

// All chances must add up to 1.0
export const PRIZE_WHEEL_REWARDS: Prize[] = [
  // --- Nothing (60.96%) ---
  { type: 'nothing', value: null, chance: 0.6120, label: "Nothing" },
  
  // --- Coin Prizes (26.56% total) ---
  { type: 'coins', value: 10, chance: 0.1568, label: "10 Coins" },
  { type: 'coins', value: 50, chance: 0.08, label: "50 Coins" },
  { type: 'coins', value: 250, chance: 0.0256, label: "250 Coins" },

  // --- Reward Prizes (12.48% total) ---

  // Wallpapers (Uncommon) - 0.32% each, 0.96% total
  { type: 'reward', value: 'Penthouse View', chance: 0.0032, label: 'Penthouse View' },
  { type: 'reward', value: 'Interstellar', chance: 0.0008, label: 'Interstellar View' },

  // Common Titles - 0.6% each, 6% total
  { type: 'reward', value: 'Newbie', chance: 0.006, label: 'Newbie Title' },
  { type: 'reward', value: 'Aspirant', chance: 0.006, label: 'Aspirant Title' },
  { type: 'reward', value: 'Penny Pincher', chance: 0.006, label: 'Penny Pincher Title' },
  { type: 'reward', value: 'Beginner Investor', chance: 0.006, label: 'Beginner Investor Title' },
  { type: 'reward', value: 'Budget Boss', chance: 0.006, label: 'Budget Boss Title' },
  { type: 'reward', value: 'The Regular', chance: 0.006, label: 'The Regular Title' },
  { type: 'reward', value: 'Apprentice', chance: 0.006, label: 'Apprentice Title' },
  { type: 'reward', value: 'Hobbyist', chance: 0.006, label: 'Hobbyist Title' },
  { type: 'reward', value: 'Go-Getter', chance: 0.006, label: 'Go-Getter Title' },
  { type: 'reward', value: 'Up-and-Comer', chance: 0.006, label: 'Up-and-Comer Title' },
  
  // Uncommon Titles - 0.32% each, 3.2% total
  { type: 'reward', value: 'Entrepreneur', chance: 0.0032, label: 'Entrepreneur Title' },
  { type: 'reward', value: 'Day Trader', chance: 0.0032, label: 'Day Trader Title' },
  { type: 'reward', value: 'Specialist', chance: 0.0032, label: 'Specialist Title' },
  { type: 'reward', value: 'Influencer', chance: 0.0032, label: 'Influencer Title' },
  { type: 'reward', value: 'The Professional', chance: 0.0032, label: 'The Professional Title' },
  { type: 'reward', value: 'Risk Taker', chance: 0.0032, label: 'Risk Taker Title' },
  { type: 'reward', value: 'Tastemaker', chance: 0.0032, label: 'Tastemaker Title' },
  { type: 'reward', value: 'Trailblazer', chance: 0.0032, label: 'Trailblazer Title' },
  { type: 'reward', value: 'High-Flyer', chance: 0.0032, label: 'High-Flyer Title' },
  { type: 'reward', value: 'Artisan', chance: 0.0032, label: 'Artisan Title' },

  // Rare Titles - 0.16% each, 1.6% total
  { type: 'reward', value: 'Financier', chance: 0.0016, label: 'Financier Title' },
  { type: 'reward', value: 'Mogul', chance: 0.0016, label: 'Mogul Title' },
  { type: 'reward', value: 'Magnate', chance: 0.0016, label: 'Magnate Title' },
  { type: 'reward', value: 'Collector', chance: 0.0016, label: 'Collector Title' },
  { type: 'reward', value: 'The Connoisseur', chance: 0.0016, label: 'The Connoisseur Title' },
  { type: 'reward', value: 'Visionary', chance: 0.0016, label: 'Visionary Title' },
  { type: 'reward', value: 'Socialite', chance: 0.0016, label: 'Socialite Title' },
  { type: 'reward', value: 'Power Broker', chance: 0.0016, label: 'Power Broker Title' },
  { type: 'reward', value: 'Tycoon', chance: 0.0016, label: 'Tycoon Title' },
  { type: 'reward', value: 'Virtuoso', chance: 0.0016, label: 'Virtuoso Title' },

  // Epic Titles - 0.08% each, 0.8% total
  { type: 'reward', value: 'Titan of Industry', chance: 0.0008, label: 'Titan of Industry Title' },
  { type: 'reward', value: 'Market Maestro', chance: 0.0008, label: 'Market Maestro Title' },
  { type: 'reward', value: 'The High Roller', chance: 0.0008, label: 'The High Roller Title' },
  { type: 'reward', value: 'Philanthropist', chance: 0.0008, label: 'Philanthropist Title' },
  { type: 'reward', value: 'Kingmaker', chance: 0.0008, label: 'Kingmaker Title' },
  { type: 'reward', value: 'World-Shaker', chance: 0.0008, label: 'World-Shaker Title' },
  { type: 'reward', value: 'The Vanguard', chance: 0.0008, label: 'The Vanguard Title' },
  { type: 'reward', value: 'Rainmaker', chance: 0.0008, label: 'Rainmaker Title' },
  { type: 'reward', value: 'Wolf of the Exchange', chance: 0.0008, label: 'Wolf of the Exchange Title' },
  { type: 'reward', value: 'Shadow Broker', chance: 0.0008, label: 'Shadow Broker Title' },
  
  // Legendary Titles & Item - 0.04% each, 0.24% total
  { type: 'reward', value: 'Golden Ticket', chance: 0.0004, label: "RARE: Golden Ticket!" },
  { type: 'reward', value: 'Oracle of Wealth', chance: 0.0004, label: 'Oracle of Wealth Title' },
  { type: 'reward', value: 'Architect of Fate', chance: 0.0004, label: 'Architect of Fate Title' },
  { type: 'reward', value: 'Galactic Overlord', chance: 0.0004, label: 'Galactic Overlord Title' },
  { type: 'reward', value: 'The Ascended', chance: 0.0004, label: 'The Ascended Title' },
  { type: 'reward', value: 'Living Myth', chance: 0.0004, label: 'Living Myth Title' },
];

export const CLICK_UPGRADE_BASE_COST = 100;