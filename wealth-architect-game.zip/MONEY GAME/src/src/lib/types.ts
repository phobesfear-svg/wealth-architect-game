export type Stock = {
  ticker: string;
  name: string;
  price: number;
  volatility: number;
  sector: string;
  history: number[];
  changePct: number;
};

export type BusinessType =
  | "Food Stall"
  | "Online Shop"
  | "Cafe"
  | "Tech Startup"
  | "Consultancy"
  | "Property Rental"
  | "Freelance Writer"
  | "Vending Machine Route"
  | "Real Estate Agency"
  | "AI SaaS Startup";

export type BusinessState =
  | "startup"
  | "running"
  | "thriving"
  | "struggling"
  | "stalled"
  | "failed";

export type Business = {
  id: string;
  btype: BusinessType;
  startupCost: number;
  baseIncome: number;
  successChance: number;
  state: BusinessState;
  daysRunning: number;
  totalEarned: number;
  incomeToday: number;
  customersToday: number;
  supplies: number;
  supplyCost: number;
  level: number;
};

export type JobName =
  | "Unemployed"
  | "Retail Assistant"
  | "Office Clerk"
  | "Graphic Designer"
  | "Software Dev"
  | "Marketing Manager"
  | "Hedge Fund Analyst";

export type Job = {
  daily_income: number;
  description: string;
};

export type AssetName =
  | "Luxury Apartment"
  | "Sports Car"
  | "Private Yacht"
  | "Designer Watch"
  | "Art Collection"
  | "Private Jet";

export type Asset = {
  name: AssetName;
  cost: number;
  type: 'Property' | 'Vehicle' | 'Luxury Good';
};

export type Player = {
  cash: number;
  job: JobName;
  holdings: { [ticker: string]: number };
  businesses: Business[];
  assets: Asset[];
  coins: number;
  milestonesHit: Set<number>;
  totalExpensesPaid: number;
  totalIncomeEarned: number;
  interviewCooldowns: { [jobName: string]: number };
  activeBackground: string;
  unlockedRewards: string[];
  gameMode: 'easy' | 'hard';
  clickPower: number;
  clickLevel: number;
};

export type Prize = {
  type: 'coins' | 'reward' | 'nothing';
  value: number | string | null;
  chance: number;
  label: string;
};

export type ModeSave = {
  day: number;
  player: Player;
  stocks: { [ticker: string]: Stock };
  eventLog: string[];
};

export type GameState = {
  day: number;
  player: Player;
  stocks: { [ticker: string]: Stock };
  eventLog: string[];
  pendingEvent: RandomEvent | null;
  isPaused: boolean;
  lastSpunPrize: Prize | null;
  modeSaves: {
    easy?: ModeSave;
    hard?: ModeSave;
  };
};

export type Milestone = {
  threshold: number;
  coins: number;
  label: string;
  desc: string;
};

export type RandomEvent = {
  name: string;
  effect: number;
  msg: string;
};

export type InterviewQuestion = {
  q: string;
  answers: string[];
  correct: string;
};

export type InterviewData = {
  min_cash: number;
  questions: { q: string; answers: string[] }[];
};

export type Reward = {
  cost: number;
  name: string;
  type: "title" | "wallpaper" | "cosmetic" | "badge" | "item";
  desc: string;
  value?: string;
  rarity?: 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary';
};
