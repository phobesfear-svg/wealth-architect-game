"use client";

import { useMemo } from 'react';
import { GameProvider } from '@/contexts/game-context';
import { Header } from '@/components/layout/header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DashboardTab } from '@/components/tabs/dashboard-tab';
import { JobsTab } from '@/components/tabs/jobs-tab';
import { BusinessTab } from '@/components/tabs/business-tab';
import { InvestmentsTab } from '@/components/tabs/investments-tab';
import { AssetsTab } from '@/components/tabs/assets-tab';
import { RewardsTab } from '@/components/tabs/rewards-tab';
import { SettingsTab } from '@/components/tabs/settings-tab';
import { LogTab } from '@/components/tabs/log-tab';
import { ScrollArea } from './ui/scroll-area';
import { useGame } from '@/hooks/use-game';
import { cn } from '@/lib/utils';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import {
  LayoutDashboard,
  Briefcase,
  Building,
  TrendingUp,
  Gem,
  Trophy,
  ScrollText,
  Settings,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";


const TABS = [
  { key: "dashboard", label: "Dashboard", icon: <LayoutDashboard />, component: <DashboardTab /> },
  { key: "jobs", label: "Jobs", icon: <Briefcase />, component: <JobsTab /> },
  { key: "business", label: "Business", icon: <Building />, component: <BusinessTab /> },
  { key: "investments", label: "Investments", icon: <TrendingUp />, component: <InvestmentsTab /> },
  { key: "assets", label: "Assets", icon: <Gem />, component: <AssetsTab /> },
  { key: "rewards", label: "Rewards", icon: <Trophy />, component: <RewardsTab /> },
  { key: "settings", label: "Settings", icon: <Settings />, component: <SettingsTab /> },
  { key: "log", label: "Log", icon: <ScrollText />, component: <LogTab /> },
];

function GameContent() {
  const { state } = useGame();
  const { player, netWorth } = state;

  const backgroundValue = useMemo(() => {
    if (player.activeBackground) {
      return player.activeBackground; 
    }
    if (netWorth >= 100_000_000) {
      return 'garage';
    }
    return 'bg-animated-blue';
  }, [netWorth, player.activeBackground]);

  // Dynamic Theme Colors based on background - using high-saturation values for readability
  const themeStyles = useMemo(() => {
    const themes: Record<string, string> = {
      'bg-animated-blue': '217 89% 60%', // Vibrant Blue
      'bedroom': '38 95% 58%',          // Warm Gold
      'penthouse': '185 100% 48%',       // Vivid Cyan
      'nebula': '285 85% 65%',           // Electric Purple
      'garage': '210 20% 75%',           // Bright Silver
    };
    
    const color = themes[backgroundValue] || themes['bg-animated-blue'];
    return { '--primary': color } as React.CSSProperties;
  }, [backgroundValue]);

  const backgroundStyle = useMemo(() => {
    const image = PlaceHolderImages.find(img => img.id === backgroundValue);
    if (image) {
      return { backgroundImage: `url(${image.imageUrl})`, ...themeStyles };
    }
    return themeStyles; 
  }, [backgroundValue, themeStyles]);

  const backgroundClass = useMemo(() => {
    const image = PlaceHolderImages.find(img => img.id === backgroundValue);
    if (image) {
      return 'bg-cover bg-center bg-fixed';
    }
    return backgroundValue || 'bg-background';
  }, [backgroundValue]);


  return (
    <div className="w-full h-full font-code text-foreground">
      <div
        className={cn(
          "h-full transition-all duration-700",
          backgroundClass
        )}
        style={backgroundStyle}
      >
        <div className="flex flex-col h-full pt-[env(safe-area-inset-top)] bg-black/40">
          <Header />
          <Tabs defaultValue="dashboard" className="flex flex-col flex-grow overflow-hidden w-full">
            <TooltipProvider>
              <div className="w-full bg-card/90 backdrop-blur-xl border-b border-border/50">
                <TabsList className="rounded-none grid w-full max-w-screen-2xl mx-auto grid-cols-8 h-auto p-1 bg-transparent border-none">
                  {TABS.map(tab => (
                    <Tooltip key={tab.key}>
                      <TooltipTrigger asChild>
                        <TabsTrigger 
                          value={tab.key} 
                          className="text-xs flex-shrink-0 flex-grow h-12 rounded-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-[0_0_20px_rgba(var(--primary),0.5)]"
                        >
                          {tab.icon}
                        </TabsTrigger>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{tab.label}</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </TabsList>
              </div>
            </TooltipProvider>
            <ScrollArea className="flex-grow">
              <div className="w-full max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-12 pb-12">
                {TABS.map(tab => (
                  <TabsContent key={tab.key} value={tab.key} className="pt-6 outline-none">
                    {tab.component}
                  </TabsContent>
                ))}
              </div>
            </ScrollArea>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export function GameUI() {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
}
