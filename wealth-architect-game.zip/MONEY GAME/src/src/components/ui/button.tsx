import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-lg text-sm font-bold tracking-tight ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-95 drop-shadow-sm",
  {
    variants: {
      variant: {
        default: 
          "bg-primary/30 text-foreground border-2 border-primary/70 hover:bg-primary/40 hover:border-primary shadow-[0_0_15px_rgba(var(--primary),0.25)] backdrop-blur-md",
        destructive:
          "bg-destructive/30 text-destructive-foreground border-2 border-destructive/70 hover:bg-destructive/40 hover:border-destructive shadow-[0_0_15px_rgba(248,81,73,0.25)] backdrop-blur-md",
        outline:
          "border-2 border-input bg-background/40 hover:bg-accent/30 hover:text-accent-foreground hover:border-accent backdrop-blur-md shadow-sm",
        secondary:
          "bg-secondary/60 text-secondary-foreground border-2 border-border/90 hover:bg-secondary/80 hover:border-foreground/60 backdrop-blur-md",
        ghost: "hover:bg-accent/30 hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }