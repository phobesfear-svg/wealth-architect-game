"use client";

import { useMemo, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { PRIZE_WHEEL_REWARDS, REWARDS } from '@/lib/constants';

interface PrizeScrollerProps {
  isSpinning: boolean;
  resultIndex: number | null;
}

const prizes = PRIZE_WHEEL_REWARDS;
const REPEATS = 5;
const ITEM_WIDTH = 48; // w-12 = 3rem = 48px

const rarityColorMap: Record<string, string> = {
    'Common': 'text-gray-400',
    'Uncommon': 'text-green-400',
    'Rare': 'text-blue-400',
    'Epic': 'text-purple-500',
    'Legendary': 'text-yellow-500',
};

// Use a fixed shuffle so it's consistent across renders
const shuffledPrizes = [...prizes].sort(() => 0.5 - Math.random());
const repeatedPrizes = Array(REPEATS).fill(0).flatMap(() => shuffledPrizes);

export function PrizeScroller({ isSpinning, resultIndex }: PrizeScrollerProps) {
  const scrollerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!scrollerRef.current) return;

    const scroller = scrollerRef.current;
    
    // Reset to start position
    if (!isSpinning && resultIndex === null) {
        scroller.style.transition = 'none';
        const startPosition = Math.floor(repeatedPrizes.length / 2) * ITEM_WIDTH - (scroller.parentElement!.clientWidth / 2) + (ITEM_WIDTH / 2);
        scroller.style.transform = `translateX(-${startPosition}px)`;
        return;
    }

    if (isSpinning && resultIndex !== null) {
      const targetPrize = prizes[resultIndex];
      // Find the prize in the last 2/3rds of the reel to ensure a long spin
      const targetZoneStart = Math.floor(repeatedPrizes.length * 0.66);
      let finalIndex = -1;
      for (let i = targetZoneStart; i < repeatedPrizes.length; i++) {
        if (repeatedPrizes[i].label === targetPrize.label) {
          finalIndex = i;
          break;
        }
      }
      
      // Fallback if not found
      if (finalIndex === -1) {
          finalIndex = repeatedPrizes.findIndex(p => p.label === targetPrize.label);
          if (finalIndex === -1) finalIndex = Math.floor(repeatedPrizes.length / 2);
      }
      
      if (finalIndex !== -1) {
        const parentWidth = scroller.parentElement!.clientWidth;
        // Calculate position to center the middle of the prize
        const targetPosition = (finalIndex * ITEM_WIDTH) + (ITEM_WIDTH / 2);
        // Offset by half the parent width to center it in the viewport
        const offset = parentWidth / 2;
        const finalTranslateX = targetPosition - offset;

        // Add a random jitter to make it look more natural
        const jitter = (Math.random() - 0.5) * (ITEM_WIDTH * 0.3);

        scroller.style.transition = 'transform 5s cubic-bezier(0.25, 1, 0.5, 1)';
        scroller.style.transform = `translateX(-${finalTranslateX + jitter}px)`;
      }
    }
  }, [isSpinning, resultIndex]);
  
  return (
    <div className="relative h-32 w-full overflow-hidden flex items-center">
        {/* Scroller track */}
        <div
            ref={scrollerRef}
            className={'flex h-16 items-center'}
        >
            {repeatedPrizes.map((prize, index) => {
                let textColor = 'text-white';
                if (prize.type === 'reward') {
                    const rewardDetails = REWARDS.find(r => r.name === prize.value);
                    if (rewardDetails?.rarity) {
                        textColor = rarityColorMap[rewardDetails.rarity] || 'text-white';
                    }
                } else if (prize.type === 'coins') {
                    textColor = 'text-fg-yellow';
                } else if (prize.type === 'nothing') {
                    textColor = 'text-muted-foreground';
                }

                 return (
                    <div
                        key={`${prize.label}-${index}`}
                        className="w-12 h-16 flex-shrink-0 rounded-lg border border-border p-1 bg-card flex flex-col items-center justify-center space-y-1"
                    >
                        <p className={cn("text-[7px] text-center font-bold break-words leading-tight", textColor)}>
                            {prize.label.replace(/RARE: |!| Title/g, '')}
                        </p>
                        {prize.type === 'coins' && <p className="text-[10px] font-black text-fg-yellow">{prize.value}</p>}
                    </div>
                )
            })}
        </div>

        {/* The Pointer (Selection Box) - Fully Orange */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-20 border-x-2 border-orange-500 z-10 pointer-events-none" 
            style={{boxShadow: '0 0 15px rgba(249, 115, 22, 0.6)'}}>
             {/* Top Triangle */}
             <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[8px] border-b-orange-500" />
             {/* Bottom Triangle */}
             <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-orange-500" />
        </div>
    </div>
  );
}
