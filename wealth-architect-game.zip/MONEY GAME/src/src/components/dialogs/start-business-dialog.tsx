"use client";

import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { BUSINESS_TYPES } from '@/lib/constants';
import type { BusinessType } from '@/lib/types';
import { cn } from '@/lib/utils';

interface StartBusinessDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function StartBusinessDialog({ open, onOpenChange }: StartBusinessDialogProps) {
  const { state, dispatch } = useGame();
  const { player } = state;
  const { toast } = useToast();

  const handleLaunch = (btype: BusinessType) => {
    const cost = BUSINESS_TYPES[btype][0];
    if (player.cash < cost) {
      toast({
        variant: "destructive",
        title: "Insufficient Funds",
        description: `Need £${cost.toLocaleString()} to launch, but you only have £${player.cash.toFixed(2)}.`,
      });
      return;
    }
    dispatch({ type: 'START_BUSINESS', payload: { btype } });
    toast({
      title: "Business Launched!",
      description: `Invested £${cost.toLocaleString()} to start a ${btype}!`,
    });
    dispatch({ type: 'ADD_LOG', payload: `Invested £${cost.toLocaleString()} to start a ${btype}!` });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>🏢 START A BUSINESS</DialogTitle>
          <DialogDescription>Success is NOT guaranteed. The startup phase lasts 7 days.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-4 py-4 max-h-[60vh] overflow-y-auto">
          {Object.entries(BUSINESS_TYPES).map(([btype, config]) => {
            const [cost, income, chance, risk] = config;
            const canAfford = player.cash >= cost;
            const riskColor = risk === "Low Risk" ? "text-fg-green" : risk === "Medium Risk" ? "text-fg-yellow" : "text-fg-red";
            return (
              <Card key={btype}>
                <CardHeader>
                  <CardTitle>{btype}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Cost: <span className="font-bold">£{cost.toLocaleString()}</span></p>
                  <p>~£{income}/day | {Math.round(chance * 100)}% success</p>
                  <p className={cn("font-bold", riskColor)}>● {risk}</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" onClick={() => handleLaunch(btype as BusinessType)} disabled={!canAfford}>
                    Launch
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
