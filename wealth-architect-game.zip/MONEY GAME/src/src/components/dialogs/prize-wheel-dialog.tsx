"use client";

import { useState, useEffect, useMemo } from 'react';
import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Coins } from 'lucide-react';
import { PRIZE_WHEEL_COST, PRIZE_WHEEL_REWARDS, REWARDS } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { PrizeScroller } from '@/components/ui/prize-scroller';

interface PrizeWheelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const rarityColorMap: Record<string, string> = {
    'Common': 'text-gray-400',
    'Uncommon': 'text-green-400',
    'Rare': 'text-blue-400',
    'Epic': 'text-purple-500',
    'Legendary': 'text-yellow-500 animate-pulse', // Legendary pulses
};

export function PrizeWheelDialog({ open, onOpenChange }: PrizeWheelDialogProps) {
  const { state, dispatch } = useGame();
  const { player, lastSpunPrize } = state;
  const { toast } = useToast();
  const [isSpinning, setSpinning] = useState(false);
  const [resultIndex, setResultIndex] = useState<number | null>(null);


  useEffect(() => {
    // Reset state when dialog is closed
    if (!open) {
      setTimeout(() => {
        setSpinning(false);
        setResultIndex(null);
        dispatch({ type: 'CLEAR_SPIN_RESULT' });
      }, 500); // Delay to allow animations to finish
    }
  }, [open, dispatch]);

  const handleSpin = () => {
    if (isSpinning) return;
    if (player.coins < PRIZE_WHEEL_COST) {
      toast({ variant: "destructive", title: "Not Enough Coins", description: `You need ${PRIZE_WHEEL_COST} coins to spin.` });
      return;
    }
    
    setResultIndex(null);
    dispatch({ type: 'CLEAR_SPIN_RESULT' });
    
    setTimeout(() => {
        setSpinning(true);
        dispatch({ type: 'SPIN_WHEEL' });

        const animationTime = 5500; // a bit longer than the CSS transition
        setTimeout(() => {
            setSpinning(false);
        }, animationTime);
    }, 100);
  };
  
  // When the game state updates with the prize, find its index.
  useEffect(() => {
    if (lastSpunPrize) {
      const index = PRIZE_WHEEL_REWARDS.findIndex(p => p.label === lastSpunPrize.label);
      if (index !== -1) {
        setResultIndex(index);
      }
    }
  }, [lastSpunPrize]);

  const canAfford = player.coins >= PRIZE_WHEEL_COST;
  const showResultText = !isSpinning && lastSpunPrize && resultIndex !== null;

  const resultTextColor = useMemo(() => {
    if (!lastSpunPrize) return 'text-primary';
    if (lastSpunPrize.type === 'coins') return 'text-fg-yellow';
    if (lastSpunPrize.type === 'nothing') return 'text-muted-foreground';
    
    const rewardDetails = REWARDS.find(r => r.name === lastSpunPrize.value);
    if (rewardDetails?.rarity) {
        return rarityColorMap[rewardDetails.rarity] || 'text-primary';
    }
    
    return 'text-primary';
  }, [lastSpunPrize]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[320px]">
        <DialogHeader className="p-2 pt-0 text-center">
          <DialogTitle>🎡 Prize Scroller</DialogTitle>
          <DialogDescription>
            Spend {PRIZE_WHEEL_COST} coins for a chance to win!
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center justify-center my-2">
            <div className="w-48">
              <PrizeScroller isSpinning={isSpinning} resultIndex={resultIndex} />
            </div>

            {showResultText && (
                <div className="text-center p-2 mt-2">
                  <p className="text-muted-foreground">You won...</p>
                  <h3 className={cn("text-2xl font-bold", resultTextColor)}>
                    {lastSpunPrize?.label}
                  </h3>
                </div>
            )}
        </div>

        <DialogFooter className="flex-col sm:flex-col sm:space-x-0 gap-2 p-2 pt-0">
           <Button onClick={handleSpin} disabled={isSpinning || !canAfford} size="lg">
             {isSpinning ? 'Spinning...' : (lastSpunPrize ? 'Spin Again' : `Spin for ${PRIZE_WHEEL_COST} coins`)}
             <Coins className="ml-2 h-4 w-4" />
           </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}