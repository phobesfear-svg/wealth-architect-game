"use client";

import { useState, useEffect } from 'react';
import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { JOB_INTERVIEWS, INTERVIEW_PASS_THRESHOLD } from '@/lib/constants';
import type { JobName, InterviewQuestion } from '@/lib/types';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

interface InterviewDialogProps {
  jobName: JobName;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export function InterviewDialog({ jobName, open, onOpenChange }: InterviewDialogProps) {
  const { dispatch } = useGame();
  const { toast } = useToast();
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<{ text: string; correct: boolean } | null>(null);
  const [isFinished, setFinished] = useState(false);

  useEffect(() => {
    if (open) {
      const interview = JOB_INTERVIEWS[jobName];
      const shuffledQuestions = interview.questions.map(q => {
        const correctAnswer = q.answers[0];
        const shuffledAnswers = shuffleArray(q.answers);
        return { q: q.q, answers: shuffledAnswers, correct: correctAnswer };
      });
      setQuestions(shuffledQuestions);
      setCurrentQuestionIndex(0);
      setScore(0);
      setFeedback(null);
      setFinished(false);
    }
  }, [open, jobName]);

  const handleAnswer = (answer: string) => {
    const isCorrect = answer === questions[currentQuestionIndex].correct;
    if (isCorrect) {
      setScore(s => s + 1);
    }
    setFeedback({ text: isCorrect ? '✔ Correct!' : `✘ Wrong. Best answer was: "${questions[currentQuestionIndex].correct}"`, correct: isCorrect });

    setTimeout(() => {
      setFeedback(null);
      if (currentQuestionIndex + 1 < questions.length) {
        setCurrentQuestionIndex(i => i + 1);
      } else {
        setFinished(true);
      }
    }, 1500);
  };

  const passThreshold = INTERVIEW_PASS_THRESHOLD[jobName];
  const passed = score >= passThreshold;

  const handleClose = () => {
    if (isFinished) {
      if (passed) {
        dispatch({ type: 'SET_JOB', payload: { jobName } });
        toast({ title: '🎉 Hired!', description: `You are now a ${jobName}.` });
        dispatch({ type: 'ADD_LOG', payload: `🎉 Hired as ${jobName}!` });
      } else {
        dispatch({ type: 'SET_JOB', payload: { jobName: 'Unemployed', cooldown: 3 } });
        toast({ variant: 'destructive', title: '😔 Interview Failed', description: `Reapply in 3 days.` });
        dispatch({ type: 'ADD_LOG', payload: `Failed interview for ${jobName}.` });
      }
    }
    onOpenChange(false);
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>📋 INTERVIEW: {jobName.toUpperCase()}</DialogTitle>
          <DialogDescription>Choose the best answer to pass the assessment.</DialogDescription>
        </DialogHeader>
        
        <div className="max-h-[60vh] overflow-y-auto pr-2 space-y-4">
          {!isFinished && currentQuestion ? (
            <div>
              <p className="text-sm text-muted-foreground mb-4">Question {currentQuestionIndex + 1} of {questions.length}</p>
              <p className="font-bold mb-4">{currentQuestion.q}</p>
              <div className="space-y-2">
                {currentQuestion.answers.map((ans, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-3 px-4 whitespace-normal break-words"
                    onClick={() => handleAnswer(ans)}
                    disabled={!!feedback}
                  >
                    {ans}
                  </Button>
                ))}
              </div>
              {feedback && (
                <p className={cn("mt-4 font-bold animate-in fade-in slide-in-from-top-1", feedback.correct ? 'text-fg-green' : 'text-fg-red')}>
                  {feedback.text}
                </p>
              )}
            </div>
          ) : (
             <div className="py-6">
              <h3 className="text-xl font-bold text-center mb-2">Interview Complete</h3>
              <p className={cn("text-lg text-center font-bold break-words", passed ? 'text-fg-green' : 'text-fg-red')}>
                  {passed ? `🎉 Score: ${score}/${questions.length} — HIRED as ${jobName}!` : `😔 Score: ${score}/${questions.length} — You needed ${passThreshold} to pass. Reapply in 3 days.`}
              </p>
             </div>
          )}
        </div>

        <DialogFooter className="pt-4 border-t border-border/50">
            {isFinished && <Button onClick={handleClose} className="w-full sm:w-auto">Finish Assessment</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}