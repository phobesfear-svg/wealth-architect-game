'use client';

// This component is not used as Firebase login has been removed.
export function LoginUI() {
  return null;
}
