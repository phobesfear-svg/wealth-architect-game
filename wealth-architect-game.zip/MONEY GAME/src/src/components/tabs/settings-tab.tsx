"use client";

import { useGame } from '@/hooks/use-game';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Settings, Gamepad2, Skull, Zap, RefreshCcw, AlertTriangle, Download, Upload } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';

export function SettingsTab() {
  const { state, dispatch } = useGame();
  const { player } = state;
  const { toast } = useToast();

  const handleModeChange = (value: 'easy' | 'hard') => {
    dispatch({ type: 'SET_GAME_MODE', payload: value });
    toast({ title: "Mode Swapped", description: `You are now in ${value.toUpperCase()} mode. Progress is saved separately.` });
  };

  const handleReset = () => {
    dispatch({ type: 'RESET_MODE' });
    toast({ title: "Progress Reset", description: `Your ${player.gameMode.toUpperCase()} profile has been wiped.` });
  };

  const handleExport = () => {
    try {
      const serializableState = {
        ...state,
        player: {
          ...state.player,
          milestonesHit: Array.from(state.player.milestonesHit),
        },
        lastSpunPrize: null,
      };
      
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(serializableState, null, 2));
      const downloadAnchorNode = document.createElement('a');
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", `wealth_architect_save_${player.gameMode}_day${state.day}.json`);
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
      
      toast({ title: "Save Exported", description: "Your progress has been downloaded as a JSON file." });
    } catch (err) {
      toast({ variant: "destructive", title: "Export Failed", description: "Could not generate save file." });
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        dispatch({ type: 'SET_STATE', payload: json });
        toast({ title: "Save Imported", description: "Your progress has been successfully restored." });
      } catch (err) {
        toast({ variant: "destructive", title: "Import Failed", description: "Invalid or corrupted save file." });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-black uppercase tracking-tighter flex items-center justify-center gap-3">
          <Settings className="w-8 h-8 text-primary" /> System Settings
        </h2>
        <p className="text-muted-foreground">Configure your simulation experience.</p>
      </div>

      <Card className="border-primary/20 bg-card/40 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-primary" /> Simulation Difficulty
          </CardTitle>
          <CardDescription>Each mode has its own independent save slot.</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={player.gameMode}
            onValueChange={(val) => handleModeChange(val as 'easy' | 'hard')}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <div className={cn(
              "relative flex items-center space-x-4 p-4 rounded-lg border-2 transition-all cursor-pointer",
              player.gameMode === 'easy' ? "border-fg-green bg-fg-green/10" : "border-border/50 hover:border-border"
            )}>
              <RadioGroupItem value="easy" id="easy" className="sr-only" />
              <Label htmlFor="easy" className="flex flex-col gap-1 cursor-pointer w-full">
                <div className="flex items-center gap-2 font-black text-fg-green">
                  <Zap className="w-4 h-4" /> EASY MODE
                </div>
                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">
                  Click to earn. Rapid progression.
                </span>
              </Label>
            </div>

            <div className={cn(
              "relative flex items-center space-x-4 p-4 rounded-lg border-2 transition-all cursor-pointer",
              player.gameMode === 'hard' ? "border-fg-red bg-fg-red/10" : "border-border/50 hover:border-border"
            )}>
              <RadioGroupItem value="hard" id="hard" className="sr-only" />
              <Label htmlFor="hard" className="flex flex-col gap-1 cursor-pointer w-full">
                <div className="flex items-center gap-2 font-black text-fg-red">
                  <Skull className="w-4 h-4" /> HARD MODE
                </div>
                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">
                  The classic simulation. Strategic & challenging.
                </span>
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      <Card className="border-primary/20 bg-card/40 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5 text-primary" /> Save Data Management
          </CardTitle>
          <CardDescription>Export your game progress to a file or import a previous save.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button variant="outline" className="w-full h-12" onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" /> Export Save Data
          </Button>
          <div className="relative w-full">
            <Button variant="outline" className="w-full h-12 pointer-events-none">
              <Upload className="w-4 h-4 mr-2" /> Import Save Data
            </Button>
            <input 
              type="file" 
              accept=".json" 
              onChange={handleImport} 
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" 
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-destructive/30 bg-destructive/5 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <RefreshCcw className="w-5 h-5" /> Danger Zone
          </CardTitle>
          <CardDescription>Manage your current save data.</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 rounded-lg bg-background/20 border border-destructive/20">
              <div className="text-center md:text-left">
                <p className="font-black text-sm uppercase">Reset {player.gameMode.toUpperCase()} Mode</p>
                <p className="text-[10px] text-muted-foreground">This will wipe your cash, jobs, and businesses for this mode only.</p>
              </div>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="sm" className="w-full md:w-auto">
                    <RefreshCcw className="w-4 h-4 mr-2" /> Reset Mode
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="text-fg-red" /> Confirm Reset
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you absolutely sure? This will permanently delete your Day {state.day} progress in <strong>{player.gameMode.toUpperCase()}</strong> mode. This cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleReset} className="bg-destructive hover:bg-destructive/90">
                      Delete Everything
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
