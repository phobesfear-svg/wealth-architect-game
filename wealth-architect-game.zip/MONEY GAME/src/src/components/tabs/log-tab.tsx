"use client";

import { useGame } from '@/hooks/use-game';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';

export function LogTab() {
  const { state } = useGame();
  const { eventLog } = state;

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">📋 Activity Log</h2>
      <Card>
        <CardContent className="p-0">
          <ScrollArea className="h-[60vh]">
            <div className="p-6 font-mono text-sm space-y-2">
              {eventLog.map((log, index) => (
                <p key={index}>{log}</p>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
