"use client";

import { useState } from 'react';
import { useGame } from '@/hooks/use-game';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { JOBS, JOB_INTERVIEWS, INTERVIEW_PASS_THRESHOLD } from '@/lib/constants';
import { JobName } from '@/lib/types';
import { CheckCircle, Clock, Lock, Briefcase } from 'lucide-react';
import { InterviewDialog } from '../dialogs/interview-dialog';
import { cn } from '@/lib/utils';

export function JobsTab() {
  const { state } = useGame();
  const { player } = state;
  const [interviewingFor, setInterviewingFor] = useState<JobName | null>(null);

  const currentJobInfo = JOBS[player.job];

  return (
    <div className="space-y-6">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-3xl font-bold">Career Center</h2>
        <p className="text-muted-foreground mt-2">
          Every job requires an interview. Higher roles need better answers and minimum savings.
        </p>
        <Card className="mt-6 border-primary/50 bg-primary/5">
          <CardContent className="p-4">
            <p className="text-lg font-bold text-fg-yellow">
              Current job: <span className="text-foreground">{player.job}</span> | Daily income: <span className="text-fg-green">£{currentJobInfo.daily_income}</span>
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
        {Object.entries(JOBS).map(([jobName, jobInfo]) => {
          if (jobName === 'Unemployed') return null;

          const typedJobName = jobName as JobName;
          const isCurrent = player.job === typedJobName;
          const cooldown = player.interviewCooldowns[typedJobName] || 0;
          const interviewInfo = JOB_INTERVIEWS[typedJobName];
          const minCash = interviewInfo.min_cash;
          const canAfford = player.cash >= minCash;
          const passNeed = INTERVIEW_PASS_THRESHOLD[typedJobName];

          let status: 'current' | 'cooldown' | 'locked' | 'available' = 'available';
          if (isCurrent) status = 'current';
          else if (cooldown > 0) status = 'cooldown';
          else if (!canAfford) status = 'locked';

          return (
            <Card key={typedJobName} className={cn("flex flex-col h-full", isCurrent && "border-fg-green bg-fg-green/5")}>
              <CardHeader>
                <CardTitle className={cn(isCurrent && "text-fg-green")}>{typedJobName}</CardTitle>
                <CardDescription className="line-clamp-2 min-h-[40px]">{jobInfo.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 flex-grow">
                <p className="font-bold text-2xl text-fg-green">£{jobInfo.daily_income}/day</p>
                <div className="text-xs space-y-1 p-2 bg-secondary/30 rounded border border-border/50">
                   <p className="text-fg-blue font-bold uppercase tracking-tight">Requirement:</p>
                   <p>£{minCash.toLocaleString()} savings</p>
                   <p>Pass {passNeed}/{interviewInfo.questions.length} questions</p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                {status === 'current' && <p className="flex items-center text-fg-green font-bold w-full justify-center"><CheckCircle className="w-4 h-4 mr-2" /> Current Job</p>}
                {status === 'cooldown' && <p className="flex items-center text-muted-foreground font-bold w-full justify-center"><Clock className="w-4 h-4 mr-2" /> Reapply in {cooldown}d</p>}
                {status === 'locked' && <p className="flex items-center text-fg-red font-bold w-full justify-center"><Lock className="w-4 h-4 mr-2" /> Need £{minCash.toLocaleString()}</p>}
                {status === 'available' && <Button className="w-full" onClick={() => setInterviewingFor(typedJobName)}><Briefcase className="w-4 h-4 mr-2" /> Apply / Interview</Button>}
              </CardFooter>
            </Card>
          );
        })}
      </div>

      {interviewingFor && (
        <InterviewDialog
          jobName={interviewingFor}
          open={!!interviewingFor}
          onOpenChange={(open) => !open && setInterviewingFor(null)}
        />
      )}
    </div>
  );
}
