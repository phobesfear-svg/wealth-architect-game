
"use client";

import { useState, useMemo } from 'react';
import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowUp, ArrowDown, TrendingUp, Wallet, Minus, Plus, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export function InvestmentsTab() {
  const { state, dispatch } = useGame();
  const { stocks, player } = state;
  const [selectedTicker, setSelectedTicker] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();

  const selectedStock = selectedTicker ? stocks[selectedTicker] : null;

  const handleBuy = () => {
    if (!selectedStock || quantity <= 0) return;
    const cost = selectedStock.price * quantity;
    if (player.cash < cost) {
      toast({
        variant: "destructive",
        title: "Insufficient Funds",
        description: `Need £${cost.toFixed(2)}, but you only have £${player.cash.toFixed(2)}.`,
      });
      return;
    }
    dispatch({ type: 'BUY_STOCK', payload: { ticker: selectedStock.ticker, quantity } });
    toast({
      title: "🚀 Order Executed",
      description: `Bought ${quantity} shares of ${selectedStock.ticker}.`,
    });
  };

  const handleSell = () => {
    if (!selectedStock || quantity <= 0) return;
    const owned = player.holdings[selectedStock.ticker] || 0;
    if (quantity > owned) {
      toast({
        variant: "destructive",
        title: "Not Enough Shares",
        description: `You only own ${owned} shares of ${selectedStock.ticker}.`,
      });
      return;
    }
    const proceeds = selectedStock.price * quantity;
    dispatch({ type: 'SELL_STOCK', payload: { ticker: selectedStock.ticker, quantity } });
     toast({
      title: "📉 Position Liquidated",
      description: `Sold ${quantity} shares of ${selectedStock.ticker}.`,
    });
  };

  const tradeCost = useMemo(() => {
    if (!selectedStock) return 0;
    return selectedStock.price * quantity;
  }, [selectedStock, quantity]);
  
  const holdingsValue = useMemo(() => {
    return Object.entries(player.holdings).reduce((acc, [ticker, qty]) => {
        return acc + (stocks[ticker]?.price || 0) * qty;
    }, 0);
  }, [player.holdings, stocks]);

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-20 px-1">
      {/* Portfolio Summary Header */}
      <div className="bg-card/20 border-2 border-dashed border-border/40 rounded-lg p-4 backdrop-blur-sm">
          <div className="text-xs font-black uppercase flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-primary" /> Portfolio Summary
            </div>
            <span className="text-fg-green font-black">£{holdingsValue.toFixed(2)} Total Value</span>
          </div>
          {Object.keys(player.holdings).length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {Object.entries(player.holdings).map(([ticker, qty]) => (
                <div key={ticker} className="flex gap-2 items-center bg-background/40 px-3 py-1.5 rounded-md border border-border/30">
                  <span className="font-black text-xs">{ticker}</span>
                  <span className="text-[10px] text-muted-foreground font-bold">{qty}</span>
                  <span className="font-black text-[10px] text-primary">£{((stocks[ticker]?.price || 0) * qty).toFixed(2)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center py-2 text-[10px] font-bold text-muted-foreground italic uppercase">No active positions held.</p>
          )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 px-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="font-black uppercase tracking-tighter text-lg">Market Floor</h3>
        </div>
        
        <div className="space-y-3">
          {Object.values(stocks).map(stock => {
            const isSelected = selectedTicker === stock.ticker;
            const owned = player.holdings[stock.ticker] || 0;
            
            return (
              <div key={stock.ticker} className="space-y-2">
                {/* Stock Card */}
                <div
                  onClick={() => {
                    if (isSelected) {
                        setSelectedTicker(null);
                    } else {
                        setSelectedTicker(stock.ticker);
                        setQuantity(1);
                    }
                  }}
                  className={cn(
                    "relative overflow-hidden cursor-pointer transition-all duration-200 border-2 active:scale-[0.99] rounded-lg backdrop-blur-md",
                    isSelected 
                      ? "border-primary bg-primary/20 shadow-[0_0_20px_rgba(var(--primary),0.3)]" 
                      : "border-border/50 bg-card/30 hover:bg-card/40 hover:border-border"
                  )}
                >
                  <div className="p-4 flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-xl tracking-tighter drop-shadow-sm">{stock.ticker}</span>
                        {owned > 0 && (
                          <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded font-bold border border-primary/30">
                            OWNED: {owned}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground uppercase font-bold">{stock.name}</p>
                    </div>
                    
                    <div className="text-right space-y-1">
                      <p className="font-black text-xl drop-shadow-sm">£{stock.price.toFixed(2)}</p>
                      <div className={cn(
                        "flex items-center justify-end text-xs font-black",
                        stock.changePct >= 0 ? 'text-fg-green' : 'text-fg-red'
                      )}>
                        {stock.changePct >= 0 ? <ArrowUp className="h-3 w-3 mr-1" /> : <ArrowDown className="h-3 w-3 mr-1" />}
                        {Math.abs(stock.changePct).toFixed(2)}%
                      </div>
                    </div>
                  </div>
                </div>

                {/* Inline Trade Terminal - Appears DIRECTLY UNDERNEATH */}
                {isSelected && (
                  <Card className="border-primary/60 bg-card/60 backdrop-blur-xl border-t-4 border-2 mx-2 animate-in slide-in-from-top-2 duration-200">
                    <CardHeader className="p-4 pb-2">
                      <div className="flex justify-between items-center">
                        <div className="text-[10px] font-black uppercase tracking-widest flex items-center gap-2 text-primary">
                          <span className="w-2 h-2 bg-primary rounded-full animate-pulse shadow-[0_0_8px_rgba(var(--primary),0.8)]" />
                          Trading Terminal: {stock.ticker}
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedTicker(null)} className="h-6 w-6 p-0 hover:bg-destructive/10 hover:text-destructive">
                            <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-background/40 p-3 rounded-lg border border-border/50">
                          <p className="text-[10px] text-muted-foreground font-black uppercase mb-1">Available Capital</p>
                          <p className="font-black text-lg">£{player.cash.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                        </div>
                        <div className="bg-background/40 p-3 rounded-lg border border-border/50 text-right">
                          <p className="text-[10px] text-muted-foreground font-black uppercase mb-1">Order Cost</p>
                          <p className="font-black text-lg text-fg-yellow">£{tradeCost.toFixed(2)}</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                           <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-10 w-10 shrink-0"
                            onClick={(e) => {
                                e.stopPropagation();
                                setQuantity(q => Math.max(1, q - 1));
                            }}
                           >
                            <Minus className="h-4 w-4" />
                           </Button>
                           <Input 
                            type="number" 
                            value={quantity} 
                            onClick={(e) => e.stopPropagation()}
                            onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} 
                            className="h-10 text-center font-black text-lg bg-background/50 border-2 border-primary/30"
                           />
                           <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-10 w-10 shrink-0"
                            onClick={(e) => {
                                e.stopPropagation();
                                setQuantity(q => q + 1);
                            }}
                           >
                            <Plus className="h-4 w-4" />
                           </Button>
                        </div>
                        
                        <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
                          {[1, 10, 50, 100].map(q => (
                            <Button 
                              key={q} 
                              variant="secondary" 
                              size="sm" 
                              className="h-7 px-3 flex-shrink-0 text-[10px]" 
                              onClick={(e) => {
                                  e.stopPropagation();
                                  setQuantity(q);
                              }}
                            >
                              {q}
                            </Button>
                          ))}
                          <Button 
                            variant="secondary" 
                            size="sm" 
                            className="h-7 px-3 flex-shrink-0 font-black text-[10px]"
                            onClick={(e) => {
                                e.stopPropagation();
                                setQuantity(Math.floor(player.cash / stock.price));
                            }}
                          >
                            MAX
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 pt-2">
                        <Button onClick={(e) => { e.stopPropagation(); handleBuy(); }} className="h-12 font-black">BUY</Button>
                        <Button onClick={(e) => { e.stopPropagation(); handleSell(); }} variant="destructive" className="h-12 font-black">SELL</Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
