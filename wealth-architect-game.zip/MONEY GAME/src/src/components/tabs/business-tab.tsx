
"use client";

import { useState } from 'react';
import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, ShoppingCart, Users, ArrowUpCircle, Building, Zap, Lock, TrendingUp } from 'lucide-react';
import { StartBusinessDialog } from '../dialogs/start-business-dialog';
import type { Business, BusinessState } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { BUSINESS_UPGRADES, BUSINESS_RESOURCE_LABELS } from '@/lib/constants';


const stateInfo: Record<BusinessState, { label: string; color: string; description: string }> = {
  startup: { label: "🔧 Starting Up", color: "bg-blue-500", description: "In 7-day startup phase. Success not guaranteed." },
  running: { label: "✅ Running", color: "bg-green-500", description: "Operating normally." },
  thriving: { label: "🚀 Thriving", color: "bg-yellow-400 text-black", description: "Earning bonus income!" },
  struggling: { label: "⚠️ Struggling", color: "bg-orange-500", description: "Income reduced." },
  stalled: { label: "🛑 Stalled", color: "bg-gray-500", description: "Critical shortage! No income." },
  failed: { label: "💀 Failed", color: "bg-red-600", description: "This business has failed." },
};

function BusinessCard({ business }: { business: Business }) {
  const { state, dispatch } = useGame();
  const { player } = state;
  const { toast } = useToast();
  const info = stateInfo[business.state];
  const resourcesToHire = 10;
  
  const resourceLabel = BUSINESS_RESOURCE_LABELS[business.btype] || "Supplies";
  
  // Dynamic action label based on business type
  const isFreelance = business.btype === "Freelance Writer";
  const isService = business.btype.includes("Consultancy") || business.btype.includes("Agency");
  
  let hireActionLabel = "Hire";
  if (isFreelance) hireActionLabel = "Take on";
  else if (isService) hireActionLabel = "Service";
  else if (business.supplyCost > 0) hireActionLabel = "Buy";

  const handleBuySupplies = () => {
    dispatch({ type: 'BUY_SUPPLIES', payload: { businessId: business.id, amount: resourcesToHire } });
    toast({
      title: `${resourceLabel} Updated`,
      description: `${hireActionLabel}ed ${resourcesToHire} ${resourceLabel} for ${business.btype}.`,
    });
  }

  const currentLevel = business.level || 1;
  const isMaxLevel = currentLevel >= BUSINESS_UPGRADES.length;
  
  const currentLevelInfo = BUSINESS_UPGRADES[currentLevel - 1];
  const nextLevelInfo = !isMaxLevel ? BUSINESS_UPGRADES[currentLevel] : null;
  const upgradeCost = nextLevelInfo ? nextLevelInfo.costMultiplier * business.startupCost : 0;
  
  const canAffordUpgrade = player.cash >= upgradeCost;

  // Calculate estimated daily income based on base income and level multiplier
  const estDailyIncome = business.baseIncome * (currentLevelInfo?.incomeMultiplier || 1);

  const handleUpgrade = () => {
    if (!nextLevelInfo) return;
    
    if (player.cash < upgradeCost) {
      toast({
        variant: "destructive",
        title: "Insufficient Funds",
        description: `You need £${upgradeCost.toLocaleString()} to upgrade.`,
      });
      return;
    }
    dispatch({ type: 'UPGRADE_BUSINESS', payload: { businessId: business.id } });
    toast({
      title: "Business Upgraded!",
      description: `${business.btype} is now Level ${business.level + 1}.`,
    });
  }

  const showFooter = business.state !== 'failed';


  return (
    <Card className={cn("flex flex-col h-full border-2", business.state === 'stalled' ? 'border-destructive/50' : 'border-border')}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start gap-2">
            <div className="flex-grow min-w-0">
                <CardTitle className="truncate text-lg">{business.btype}</CardTitle>
                <div className="text-[10px] uppercase font-bold text-primary mt-1 flex items-center gap-1">
                   <Zap className="w-2 h-2" /> Level {currentLevel}
                </div>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge className={cn("text-white shrink-0", info.color)}>{info.label.split(' ')[0]}</Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{info.description}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent className="flex-grow space-y-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <p className={cn("text-3xl font-black", business.incomeToday > 0 ? "text-fg-green" : "text-muted-foreground")}>
              +£{business.incomeToday.toFixed(2)}
            </p>
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest bg-muted/30 px-1.5 py-0.5 rounded">Today</span>
          </div>
          
          <div className="flex items-center gap-2 text-primary">
            <TrendingUp className="w-3 h-3" />
            <p className="text-[10px] font-black uppercase tracking-widest">
              Est. Profit: £{estDailyIncome.toFixed(0)}/day
            </p>
          </div>

          <div className="text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1 pt-1">
            <span className='flex items-center gap-1'><Users className="w-3 h-3" /> {business.customersToday} active users</span>
            {business.supplyCost > 0 && (
              <span className={cn("font-bold flex items-center gap-1", business.supplies <= 2 ? "text-fg-red animate-pulse" : "")}>
                {resourceLabel}: {business.supplies}
              </span>
            )}
          </div>
        </div>

        <div className="text-[10px] font-mono bg-secondary/20 p-2 rounded border border-border/30 space-y-1">
           <div className="flex justify-between">
              <span>Capital Invested:</span>
              <span>£{business.startupCost.toLocaleString()}</span>
           </div>
           <div className="flex justify-between">
              <span>Lifetime Yield:</span>
              <span className="text-fg-green">£{business.totalEarned.toFixed(2)}</span>
           </div>
           <div className="flex justify-between">
              <span>Operational:</span>
              <span>{business.daysRunning} days</span>
           </div>
        </div>
      </CardContent>
      {showFooter &&
        <CardFooter className="flex-col items-stretch gap-3 pt-2 bg-secondary/5 rounded-b-lg border-t border-border/20">
            {business.state !== 'failed' && business.supplyCost > 0 && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleBuySupplies} 
                  className={cn("h-auto py-3 text-xs border-2 transition-all", business.supplies <= 2 ? "border-fg-red text-fg-red hover:bg-fg-red/10" : "border-border")}
                >
                    <ShoppingCart className="w-3 h-3 mr-2" />
                    {hireActionLabel} {resourcesToHire} {resourceLabel} (£{(business.supplyCost * resourcesToHire).toLocaleString()})
                </Button>
            )}

            <div className="w-full pt-1 border-t border-border/10 mt-1">
                {business.state === 'startup' ? (
                   <div className="flex flex-col items-center justify-center p-3 rounded bg-muted/20 border border-dashed border-border/30">
                      <Lock className="w-4 h-4 text-muted-foreground mb-1" />
                      <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">Upgrade Locked</p>
                      <p className="text-[8px] text-muted-foreground">Requires 7-day maturity period.</p>
                   </div>
                ) : isMaxLevel ? (
                    <div className="text-center p-2 bg-fg-yellow/10 border border-fg-yellow/30 rounded">
                      <p className="text-[10px] font-black text-fg-yellow uppercase tracking-[0.2em]">⭐ MAXIMUM LEVEL ACHIEVED ⭐</p>
                    </div>
                ) : (
                    <div className="space-y-2 p-1">
                      <Button
                          variant="default"
                          size="sm"
                          className={cn(
                            "w-full h-12 text-[11px] font-black shadow-[0_0_20px_rgba(var(--primary),0.4)] border-2 transition-all",
                            canAffordUpgrade ? "border-primary bg-primary/20 hover:bg-primary/30" : "border-muted-foreground/30 bg-muted/20"
                          )}
                          onClick={handleUpgrade}
                          disabled={!canAffordUpgrade}
                      >
                          <ArrowUpCircle className="w-4 h-4 mr-2" /> 
                          UPGRADE TO LVL {currentLevel + 1}
                      </Button>
                      <div className="flex justify-between items-center text-[9px] uppercase font-bold tracking-widest text-muted-foreground px-1">
                          <span>Next Tier:</span>
                          <span className="text-fg-green font-black">Income ×{nextLevelInfo?.incomeMultiplier}</span>
                      </div>
                      <p className="text-[9px] text-center text-muted-foreground font-bold">COST: £{upgradeCost.toLocaleString()}</p>
                    </div>
                )}
            </div>
        </CardFooter>
      }
    </Card>
  )
}

export function BusinessTab() {
  const { state } = useGame();
  const { businesses } = state.player;
  const [isDialogOpen, setDialogOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold uppercase tracking-tight">Venture Capital</h2>
          <p className="text-muted-foreground">
            Monitor cash flow and scale your operations. Assets without resources produce zero yield.
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="w-full md:w-auto flex-shrink-0 px-8 h-12 shadow-[0_0_20px_rgba(var(--primary),0.3)] border-2">
          <PlusCircle className="mr-2 h-5 w-5" /> Launch New Venture
        </Button>
      </div>

      {businesses.length === 0 ? (
        <Card className="text-center py-24 bg-secondary/5 border-dashed border-2">
          <CardContent className="space-y-4">
            <Building className="w-20 h-20 mx-auto text-muted-foreground/20" />
            <div>
              <p className="text-lg font-bold text-muted-foreground">Zero active operations detected.</p>
              <p className="text-muted-foreground max-w-sm mx-auto">Found your first startup to begin generating automated capital and passive daily income.</p>
            </div>
            <Button variant="outline" size="lg" onClick={() => setDialogOpen(true)} className="mt-4 border-2">
               Bootstrap Now
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {businesses.map((business) => (
            <BusinessCard key={business.id} business={business} />
          ))}
        </div>
      )}

      <StartBusinessDialog open={isDialogOpen} onOpenChange={setDialogOpen} />
    </div>
  );
}
