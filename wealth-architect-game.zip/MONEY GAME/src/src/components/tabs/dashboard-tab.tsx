"use client";

import { useGame } from '@/hooks/use-game';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { DAILY_EXPENSES, JOBS, CLICK_UPGRADE_BASE_COST } from '@/lib/constants';
import { Wallet, LineChart, CircleDollarSign, CalendarDays, MousePointer2, ArrowBigUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function DashboardTab() {
  const { state, dispatch } = useGame();
  const { day, player, eventLog, pendingEvent, netWorth } = state;
  const { toast } = useToast();

  const jobIncome = JOBS[player.job].daily_income;
  const businessIncome = player.businesses.reduce((sum, b) => sum + b.incomeToday, 0);
  const dailyIncome = jobIncome + businessIncome;
  const dailyExpenses = Object.values(DAILY_EXPENSES).reduce((sum, v) => sum + v, 0);
  const dailyNet = dailyIncome - dailyExpenses;

  const metrics = [
    { key: "day", title: "Day", value: day, color: "text-fg-blue", icon: <CalendarDays className="h-4 w-4 text-muted-foreground" /> },
    { key: "cash", title: "Cash", value: `£${player.cash.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: player.cash >= 0 ? "text-fg-green" : "text-fg-red", icon: <Wallet className="h-4 w-4 text-muted-foreground" /> },
    { key: "net_worth", title: "Net Worth", value: `£${netWorth.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: "text-fg-yellow", icon: <LineChart className="h-4 w-4 text-muted-foreground" /> },
    { key: "daily_net", title: "Daily Net", value: `${dailyNet >= 0 ? '+' : ''}£${dailyNet.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: dailyNet >= 0 ? "text-fg-green" : "text-fg-red", icon: <CircleDollarSign className="h-4 w-4 text-muted-foreground" /> },
  ];

  const handleClickMoney = () => {
    dispatch({ type: 'CLICK_MONEY' });
  };

  const nextClickUpgradeCost = CLICK_UPGRADE_BASE_COST * Math.pow(3.5, player.clickLevel - 1);
  const canAffordClickUpgrade = player.cash >= nextClickUpgradeCost;

  const handleUpgradeClick = () => {
    if (canAffordClickUpgrade) {
      dispatch({ type: 'UPGRADE_CLICK' });
      toast({ title: "👆 Clicking Upgraded!", description: `Now earning £${(player.clickPower + player.clickLevel).toFixed(2)} per click.` });
    }
  };

  return (
    <div className="space-y-6">
      {/* Prominent Cash Header */}
      <div className="text-center py-4 space-y-1">
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground opacity-70">Available Capital</p>
        <h2 className={cn(
          "text-4xl md:text-6xl font-black tracking-tighter drop-shadow-lg transition-colors duration-500",
          player.cash >= 0 ? "text-fg-green" : "text-fg-red"
        )}>
          £{player.cash.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </h2>
      </div>

      {player.gameMode === 'easy' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card 
            onClick={handleClickMoney}
            className="group cursor-pointer select-none border-fg-green/50 bg-fg-green/5 hover:bg-fg-green/10 transition-all active:scale-[0.98] h-32 flex flex-col items-center justify-center border-2"
          >
            <MousePointer2 className="w-8 h-8 text-fg-green mb-2 group-hover:scale-110 transition-transform" />
            <div className="text-center">
              <p className="text-xs font-black uppercase tracking-widest text-fg-green">CLICK TO EARN</p>
              <p className="text-2xl font-black">+£{player.clickPower.toFixed(2)}</p>
            </div>
          </Card>

          <Card className="border-primary/50 bg-primary/5 h-32 flex flex-col items-center justify-center border-2">
            <div className="text-center space-y-2">
              <p className="text-xs font-black uppercase tracking-widest text-primary">CLICK POWER: LVL {player.clickLevel}</p>
              <Button 
                size="sm" 
                variant="outline"
                onClick={handleUpgradeClick}
                disabled={!canAffordClickUpgrade}
                className="h-10 px-6"
              >
                <ArrowBigUp className="w-4 h-4 mr-2" />
                UPGRADE (£{nextClickUpgradeCost.toLocaleString(undefined, { maximumFractionDigits: 0 })})
              </Button>
            </div>
          </Card>
        </div>
      )}

      <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
        {metrics.map(metric => (
          <Card key={metric.key} className="relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-1 h-full bg-primary opacity-50" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1">
              <CardTitle className="text-xs font-black text-muted-foreground uppercase tracking-widest">{metric.title}</CardTitle>
              {metric.icon}
            </CardHeader>
            <CardContent className="pt-0">
              <div className={cn("text-lg md:text-2xl font-black truncate drop-shadow-sm", metric.color)}>{metric.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {pendingEvent && (
        <div className={cn("p-5 rounded-lg text-center font-black text-sm md:text-base border-2 backdrop-blur-md shadow-lg", pendingEvent.effect > 0 ? 'bg-green-900/60 border-fg-green text-fg-green' : 'bg-red-900/60 border-fg-red text-fg-red')}>
            ⚡ {pendingEvent.name}: {pendingEvent.msg} ({pendingEvent.effect > 0 ? '+' : ''}£{pendingEvent.effect})
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="h-full border-primary/20">
          <CardHeader className="py-4 border-b border-border/50">
            <CardTitle className="text-muted-foreground text-sm uppercase tracking-widest font-black">Daily Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="text-sm font-mono space-y-3 pt-4">
            <div className="flex justify-between border-b border-border/30 pb-2">
                <span className="text-muted-foreground">Job:</span>
                <span className="font-black text-foreground">{player.job}</span>
            </div>
            <div className="flex justify-between">
                <span>Job Income:</span>
                <span className="text-fg-green font-black">+£{jobIncome.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
                <span>Business Income:</span>
                <span className="text-fg-green font-black">+£{businessIncome.toFixed(2)}</span>
            </div>
            <div className="pt-4 border-t border-border/30">
                <p className="mb-2 text-muted-foreground font-bold uppercase text-[10px]">Ongoing Expenses:</p>
                {Object.entries(DAILY_EXPENSES).map(([name, cost]) => (
                    <div key={name} className="flex justify-between text-xs md:text-sm mb-1">
                        <span>{name}:</span>
                        <span className="text-fg-red font-bold">-£{cost.toFixed(2)}</span>
                    </div>
                ))}
            </div>
            <div className="pt-4 border-t border-dashed border-border/50 flex justify-between font-black text-primary">
                <span>Total Earned:</span>
                <span>£{player.totalIncomeEarned.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-black text-muted-foreground">
                <span>Total Spent:</span>
                <span>£{player.totalExpensesPaid.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="flex flex-col h-full border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between py-4 border-b border-border/50">
            <CardTitle className="text-muted-foreground text-sm uppercase tracking-widest font-black">Latest Activity</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow text-xs md:text-sm font-mono space-y-2 overflow-y-auto max-h-[400px] pt-4">
            {eventLog.map((log, i) => (
              <div key={i} className="border-l-4 border-primary/40 pl-3 py-2 bg-secondary/30 rounded-r-md mb-2">
                {log}
              </div>
            ))}
            {eventLog.length === 0 && <p className="text-center text-muted-foreground py-16 italic opacity-50">No activity yet.</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
