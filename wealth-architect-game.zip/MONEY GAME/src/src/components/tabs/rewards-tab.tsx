"use client";

import { useState } from 'react';
import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { REWARDS } from '@/lib/constants';
import { CheckCircle, Coins, Lock, Wallpaper, Gift, Award } from 'lucide-react';
import type { Reward } from '@/lib/types';
import { PrizeWheelDialog } from '@/components/dialogs/prize-wheel-dialog';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export function RewardsTab() {
  const { state, dispatch } = useGame();
  const { player, netWorth } = state;
  const { toast } = useToast();
  const [isWheelOpen, setWheelOpen] = useState(false);
  const [category, setCategory] = useState<'all' | 'wallpaper' | 'title'>('all');

  const handleRewardClick = (reward: Reward) => {
    const isUnlocked = player.unlockedRewards.includes(reward.name);

    if (isUnlocked) {
      if (reward.type === 'wallpaper' && reward.value) {
        dispatch({ type: 'SET_BACKGROUND', payload: reward.value });
        toast({ title: "Background Applied", description: `${reward.name} is now active.` });
      } else {
        toast({ title: "Already Owned", description: "You have already unlocked this reward." });
      }
      return;
    }
    
    if (player.coins < reward.cost) {
      toast({ variant: "destructive", title: "Not Enough Coins", description: `You need ${reward.cost} coins.` });
      return;
    }

    dispatch({ type: 'UNLOCK_REWARD', payload: reward });
    dispatch({ type: 'ADD_LOG', payload: `🏆 Unlocked reward: ${reward.name}` });
    toast({ title: "Reward Unlocked!", description: `You've unlocked ${reward.name}.` });
  };

  const handleResetBackground = () => {
    dispatch({ type: 'SET_BACKGROUND', payload: '' });
    toast({ title: "Background Reset", description: "Default view applied." });
  };

  const defaultBgName = netWorth >= 100_000_000 ? "Expensive Garage" : "Blue Flow";

  // Hide the rare prize wheel item from the direct purchase list
  const purchasableRewards = REWARDS.filter(r => r.type !== 'item');

  const filteredRewards = category === 'all'
    ? purchasableRewards
    : purchasableRewards.filter(reward => reward.type === category);

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-black uppercase tracking-tighter">🏆 Reward Center</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-4">
            <Card className="min-w-[200px] border-fg-yellow bg-fg-yellow/5">
                <CardContent className="p-4 flex items-center justify-center">
                    <p className="text-xl font-black text-fg-yellow flex items-center">
                    <Coins className="w-6 h-6 mr-2" /> {player.coins} Coins
                    </p>
                </CardContent>
            </Card>
            <Card className="min-w-[300px] border-primary cursor-pointer hover:bg-primary/5 transition-colors" onClick={() => setWheelOpen(true)}>
                <CardContent className="p-4 flex items-center justify-between">
                    <div className="text-left">
                        <p className="font-bold">Wheel of Fortune</p>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Spin for 5 Coins</p>
                    </div>
                    <Gift className="w-6 h-6 text-primary animate-bounce" />
                </CardContent>
            </Card>
        </div>
      </div>
      
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 border-b border-border/50 pb-4">
            <h3 className="text-xl font-bold uppercase tracking-widest">Storefront</h3>
            <div className="flex items-center gap-1 rounded-md bg-muted/30 backdrop-blur-md p-1 border border-border/50">
                <Button variant={category === 'all' ? 'secondary' : 'ghost'} size="sm" onClick={() => setCategory('all')}>All</Button>
                <Button variant={category === 'wallpaper' ? 'secondary' : 'ghost'} size="sm" onClick={() => setCategory('wallpaper')}>
                    <Wallpaper className="w-4 h-4 mr-2"/> Wallpapers
                </Button>
                <Button variant={category === 'title' ? 'secondary' : 'ghost'} size="sm" onClick={() => setCategory('title')}>
                    <Award className="w-4 h-4 mr-2"/> Titles
                </Button>
            </div>
        </div>

        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <Card className="flex flex-col">
                <CardHeader>
                    <CardTitle className="text-lg">Default View</CardTitle>
                    <CardDescription className="text-xs h-8">Your base view, scales with Net Worth.</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                    <p className="font-bold text-muted-foreground">
                    Current: {defaultBgName}
                    </p>
                </CardContent>
                <CardFooter>
                    <Button className="w-full" onClick={handleResetBackground} disabled={!player.activeBackground}>
                        <Wallpaper className="w-4 h-4 mr-2" />
                        Apply Default
                    </Button>
                </CardFooter>
            </Card>
            
            {filteredRewards.map(reward => {
              const isUnlocked = player.unlockedRewards.includes(reward.name);
              const canAfford = player.coins >= reward.cost;
              const isActive = reward.type === 'wallpaper' && player.activeBackground === reward.value;

              const rarityColor = {
                  'Common': 'border-gray-400 text-gray-400',
                  'Uncommon': 'border-green-400 text-green-400',
                  'Rare': 'border-blue-400 text-blue-400',
                  'Epic': 'border-purple-500 text-purple-500',
                  'Legendary': 'border-yellow-500 text-yellow-500',
              }[reward.rarity || '']

              return (
                <Card key={reward.name} className={cn("flex flex-col h-full", isActive && "border-primary bg-primary/5")}>
                  <CardHeader>
                    <div className="flex justify-between items-start gap-2">
                      <CardTitle className="text-lg leading-tight">{reward.name}</CardTitle>
                      {reward.rarity && (
                        <Badge variant="outline" className={cn('text-[8px] h-4 shrink-0', rarityColor)}>{reward.rarity}</Badge>
                      )}
                    </div>
                    <CardDescription className="text-xs line-clamp-2 h-8">{reward.desc}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow pt-2">
                    <p className="font-black text-xl text-fg-yellow flex items-center">
                      <Coins className="w-4 h-4 mr-2" /> {reward.cost}
                    </p>
                  </CardContent>
                  <CardFooter className="pt-2">
                    {isUnlocked ? (
                      reward.type === 'wallpaper' ? (
                        <Button className="w-full" onClick={() => handleRewardClick(reward)} disabled={isActive}>
                          <Wallpaper className="w-4 h-4 mr-2" />
                          {isActive ? 'Active' : 'Apply'}
                        </Button>
                      ) : (
                        <div className="flex items-center text-fg-green font-bold w-full justify-center p-2 bg-fg-green/10 rounded-md">
                          <CheckCircle className="w-4 h-4 mr-2" /> Unlocked
                        </div>
                      )
                    ) : (
                      <Button onClick={() => handleRewardClick(reward)} disabled={!canAfford} className="w-full">
                        {!canAfford && <Lock className="w-4 h-4 mr-2" />}
                        Unlock
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              )
            })}
        </div>
      </div>

      <PrizeWheelDialog open={isWheelOpen} onOpenChange={setWheelOpen} />
    </div>
  );
}
