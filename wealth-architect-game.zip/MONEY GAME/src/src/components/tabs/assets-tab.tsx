"use client";

import { useGame } from '@/hooks/use-game';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ASSETS } from '@/lib/constants';
import type { Asset } from '@/lib/types';
import { CheckCircle, Diamond, Home, Car } from 'lucide-react';
import { cn } from '@/lib/utils';

const assetIcons = {
    "Property": <Home className="w-6 h-6" />,
    "Vehicle": <Car className="w-6 h-6" />,
    "Luxury Good": <Diamond className="w-6 h-6" />,
}

export function AssetsTab() {
  const { state, dispatch } = useGame();
  const { player } = state;
  const { toast } = useToast();

  const handleBuyAsset = (asset: Asset) => {
    if (player.cash < asset.cost) {
      toast({ variant: "destructive", title: "Insufficient Funds", description: `You need £${asset.cost.toLocaleString()} to purchase the ${asset.name}.` });
      return;
    }
    
    dispatch({ type: 'BUY_ASSET', payload: { asset } });
    dispatch({ type: 'ADD_LOG', payload: `💎 Purchased ${asset.name} for £${asset.cost.toLocaleString()}` });
    toast({ title: "Asset Acquired!", description: `You are now the proud owner of a ${asset.name}.` });
  };

  const ownedAssetNames = new Set(player.assets.map(a => a.name));

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-black uppercase tracking-tighter">💎 Luxury Acquisitions</h2>
        <p className="text-muted-foreground">
          Acquire high-value assets to solidify your legacy and expand your net worth.
        </p>
      </div>
      
      {player.assets.length > 0 && (
          <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-2">
                  <CardTitle className="text-sm uppercase tracking-widest text-primary">Your Collection</CardTitle>
              </CardHeader>
              <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {player.assets.map(asset => (
                          <div key={asset.name} className="flex items-center gap-3 p-3 bg-background/40 rounded-lg border border-border/50">
                            <div className="text-primary">{assetIcons[asset.type]}</div>
                            <div className="min-w-0">
                              <p className="font-bold truncate text-sm">{asset.name}</p>
                              <p className="text-[10px] text-muted-foreground">Value: £{asset.cost.toLocaleString()}</p>
                            </div>
                          </div>
                      ))}
                  </div>
              </CardContent>
          </Card>
      )}

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {ASSETS.map(asset => {
          const isOwned = ownedAssetNames.has(asset.name);
          const canAfford = player.cash >= asset.cost;

          return (
            <Card key={asset.name} className={cn("flex flex-col h-full", isOwned && "border-fg-green/50 bg-fg-green/5")}>
              <CardHeader>
                <div className="flex justify-between items-start">
                    <CardTitle className="flex items-center gap-2 text-lg">
                        {assetIcons[asset.type]} {asset.name}
                    </CardTitle>
                </div>
                <CardDescription className="uppercase text-[10px] font-bold tracking-widest">{asset.type}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="font-black text-2xl text-fg-yellow">
                  £{asset.cost.toLocaleString()}
                </p>
              </CardContent>
              <CardFooter className="pt-2">
                {isOwned ? (
                    <div className="flex items-center text-fg-green font-bold w-full justify-center p-2 bg-fg-green/10 rounded-md">
                      <CheckCircle className="w-4 h-4 mr-2" /> Owned
                    </div>
                ) : (
                  <Button onClick={() => handleBuyAsset(asset)} disabled={!canAfford} className="w-full">
                    Purchase
                  </Button>
                )}
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </div>
  );
}
