"use client";

import { useState, useEffect } from 'react';
import { useGame } from '@/hooks/use-game';
import { Button } from '@/components/ui/button';
import { Pause, Play, Clock, Coins } from 'lucide-react';

export function Header() {
  const { state, dispatch } = useGame();
  const { isPaused, player } = state;
  const [time, setTime] = useState<Date | null>(null);
  const [lastProcessedHour, setLastProcessedHour] = useState<number | null>(null);

  useEffect(() => {
    // Set initial time on mount for client-side rendering
    const now = new Date();
    setTime(now);
    setLastProcessedHour(now.getHours());
  }, []);

  useEffect(() => {
    if (!time) return; // Don't start the timer until time is initialized
    
    const timer = setInterval(() => {
      const now = new Date();
      setTime(now);
      
      if (!isPaused && now.getHours() !== lastProcessedHour) {
        dispatch({ type: 'ADVANCE_DAY' });
        setLastProcessedHour(now.getHours());
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [isPaused, lastProcessedHour, dispatch, time]);


  const handleTogglePause = () => {
    dispatch({ type: 'TOGGLE_PAUSE' });
  };

  return (
    <header className="bg-card/80 backdrop-blur-sm px-4 py-2 border-b border-border flex items-center justify-between shrink-0 gap-2">
      <h1 className="text-sm font-bold text-fg-blue whitespace-nowrap">💰 WA</h1>
      <div className="flex items-center gap-1 text-xs justify-end w-full">
        <div className="flex items-center gap-1 text-muted-foreground">
          <Clock className="h-4 w-4" />
          <span>{time ? time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '00:00'}</span>
        </div>
        <Button variant="outline" size="sm" onClick={handleTogglePause} className="p-1 h-7 w-7 flex-shrink-0">
          {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>
        <div className="flex items-center gap-1 text-fg-yellow font-bold bg-secondary px-2 py-1 rounded-md">
          <Coins className="h-4 w-4" />
          <span className="truncate">{player.coins.toLocaleString()}</span>
        </div>
      </div>
    </header>
  );
}
