
"use client";

import React, { createContext, useReducer, useEffect, ReactNode, useState, useMemo } from 'react';
import { GameState, Stock, Player, Business, BusinessType, JobName, RandomEvent, Milestone, Reward, Asset, Prize, ModeSave } from '@/lib/types';
import { INITIAL_CASH, JOBS, DAILY_EXPENSES, BUSINESS_TYPES, INITIAL_STOCKS, MILESTONES, RANDOM_EVENTS, PRIZE_WHEEL_COST, PRIZE_WHEEL_REWARDS, REWARDS, BUSINESS_UPGRADES, CLICK_UPGRADE_BASE_COST } from '@/lib/constants';
import { useToast } from '@/hooks/use-toast';

type GameContextType = {
  state: GameState & { netWorth: number };
  dispatch: React.Dispatch<Action>;
};

const createInitialStocks = () => INITIAL_STOCKS.reduce((acc, stock) => {
  acc[stock.ticker] = { ...stock, history: [stock.price], changePct: 0 };
  return acc;
}, {} as { [ticker: string]: Stock });

const createInitialPlayer = (mode: 'easy' | 'hard'): Player => ({
  cash: INITIAL_CASH,
  job: "Unemployed",
  holdings: {},
  businesses: [],
  assets: [],
  coins: 6000, 
  milestonesHit: new Set(),
  totalExpensesPaid: 0.0,
  totalIncomeEarned: 0.0,
  interviewCooldowns: {},
  activeBackground: "",
  unlockedRewards: [],
  gameMode: mode,
  clickPower: 1,
  clickLevel: 1,
});

const initialState: GameState = {
  day: 1,
  player: createInitialPlayer('hard'),
  stocks: createInitialStocks(),
  eventLog: ["Welcome to Wealth Architect! Your journey begins."],
  pendingEvent: null,
  isPaused: false,
  lastSpunPrize: null,
  modeSaves: {},
};

function calculateNetWorth(player: Player, stocks: { [ticker: string]: Stock }): number {
  const stockValue = Object.entries(player.holdings).reduce((acc, [ticker, quantity]) => {
    return acc + (stocks[ticker]?.price || 0) * quantity;
  }, 0);
  const businessValue = player.businesses.reduce((acc, business) => {
    return acc + (business.state !== "failed" ? business.startupCost * 0.5 : 0);
  }, 0);
  const assetValue = player.assets.reduce((acc, asset) => acc + asset.cost, 0);
  return player.cash + stockValue + businessValue + assetValue;
}

type Action =
  | { type: 'ADVANCE_DAY' }
  | { type: 'TOGGLE_PAUSE' }
  | { type: 'SET_STATE'; payload: GameState }
  | { type: 'BUY_STOCK'; payload: { ticker: string; quantity: number } }
  | { type: 'SELL_STOCK'; payload: { ticker: string; quantity: number } }
  | { type: 'START_BUSINESS'; payload: { btype: BusinessType } }
  | { type: 'BUY_SUPPLIES'; payload: { businessId: string; amount: number } }
  | { type: 'UPGRADE_BUSINESS'; payload: { businessId: string } }
  | { type: 'SET_JOB'; payload: { jobName: JobName; cooldown?: number } }
  | { type: 'UNLOCK_REWARD'; payload: Reward }
  | { type: 'SET_BACKGROUND'; payload: string }
  | { type: 'ADD_LOG'; payload: string }
  | { type: 'BUY_ASSET'; payload: { asset: Asset } }
  | { type: 'SPIN_WHEEL' }
  | { type: 'CLEAR_SPIN_RESULT' }
  | { type: 'SET_GAME_MODE'; payload: 'easy' | 'hard' }
  | { type: 'CLICK_MONEY' }
  | { type: 'UPGRADE_CLICK' }
  | { type: 'RESET_MODE' };

function gameReducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'ADVANCE_DAY': {
      const newState = JSON.parse(JSON.stringify(state)) as GameState;
      newState.player.milestonesHit = new Set(state.player.milestonesHit);
      const { player, stocks } = newState;
      let notifications: string[] = [];

      for (const ticker in stocks) {
        const stock = stocks[ticker];
        const drift = 0.001;
        const shock = (Math.random() - 0.5) * 2 * stock.volatility * 2;
        const factor = Math.max(0.5, Math.min(1 + drift + shock, 1.8));
        const oldPrice = stock.price;
        stock.price = Math.max(0.5, parseFloat((stock.price * factor).toFixed(2)));
        stock.changePct = ((stock.price - oldPrice) / oldPrice) * 100;
        stock.history.push(stock.price);
        if (stock.history.length > 30) stock.history.shift();
      }

      player.businesses.forEach((b: Business) => {
        b.daysRunning += 1;
        b.incomeToday = 0.0;
        b.customersToday = 0;

        if (b.state === 'startup') {
            if (b.daysRunning >= 7) {
                if (Math.random() < b.successChance) {
                    b.state = "running";
                    notifications.push(`✅ SUCCESS: ${b.btype} has cleared startup!`);
                } else {
                    b.state = "failed";
                    notifications.push(`💀 CRITICAL: ${b.btype} collapsed during startup.`);
                }
            }
        } else if (b.state !== 'failed') {
            if (b.supplies > 0) {
                if (b.supplyCost > 0) b.supplies -= 1;
                
                const roll = Math.random();
                if (b.state === "running") {
                    if (roll < 0.05) { b.state = "failed"; notifications.push(`💀 BANKRUPTCY: ${b.btype} has closed down.`); return; }
                    else if (roll < 0.15) { b.state = "struggling"; notifications.push(`⚠️ MARKET DIP: ${b.btype} is struggling.`); }
                    else if (roll < 0.25) { b.state = "thriving"; notifications.push(`🚀 BOOM: ${b.btype} is thriving!`); }
                } else if (b.state === "thriving") {
                    if (roll < 0.20) b.state = "running";
                } else if (b.state === "struggling") {
                    if (roll < 0.10) { b.state = "failed"; notifications.push(`💀 BANKRUPTCY: ${b.btype} has failed.`); return; }
                    else if (roll < 0.30) b.state = "running";
                } else if (b.state === "stalled") {
                    b.state = "running";
                }

                const currentLevelInfo = BUSINESS_UPGRADES[b.level - 1];
                const incomeMultiplierFromLevel = currentLevelInfo ? currentLevelInfo.incomeMultiplier : 1;
                const stateMult = {"running": 1.0, "thriving": 1.8, "struggling": 0.4}[b.state] || 0;
                
                const baseCustomers = 10;
                const randomCustomers = Math.floor(Math.random() * 20);
                b.customersToday = baseCustomers + randomCustomers;
    
                const incomePerCustomer = b.baseIncome / 20; 
                const income = parseFloat((b.customersToday * incomePerCustomer * stateMult * incomeMultiplierFromLevel).toFixed(2));

                b.incomeToday = income;
                b.totalEarned += income;
            } else {
                 if (b.state !== "stalled" && b.supplyCost > 0) {
                    b.state = "stalled";
                    notifications.push(`🛑 STALLED: ${b.btype} has no resources!`);
                }
                b.incomeToday = 0;
            }
        }
      });
      
      const jobIncome = JOBS[player.job].daily_income;
      const businessIncome = player.businesses.reduce((sum, b) => sum + b.incomeToday, 0);
      const totalIncome = jobIncome + businessIncome;
      const totalExpenses = Object.values(DAILY_EXPENSES).reduce((sum, cost) => sum + cost, 0);

      player.cash += totalIncome - totalExpenses;
      player.totalIncomeEarned += totalIncome;
      player.totalExpensesPaid += totalExpenses;

      if (businessIncome > 0) {
        notifications.unshift(`Portfolio Yield: +£${businessIncome.toFixed(2)} from active operations.`);
      }
      notifications.unshift(`Day ${newState.day + 1}: +£${totalIncome.toFixed(2)} total income, -£${totalExpenses.toFixed(2)} bills.`);

      for (const job in player.interviewCooldowns) {
        if (player.interviewCooldowns[job] > 0) {
          player.interviewCooldowns[job] -= 1;
        }
        if (player.interviewCooldowns[job] <= 0) {
          delete player.interviewCooldowns[job];
        }
      }

      let pendingEvent: RandomEvent | null = null;
      if (Math.random() < 0.10) {
        const event = RANDOM_EVENTS[Math.floor(Math.random() * RANDOM_EVENTS.length)];
        player.cash += event.effect;
        pendingEvent = event;
        const sign = event.effect > 0 ? "+" : "";
        notifications.push(`⚡ EVENT: ${event.name} (${sign}£${event.effect})`);
      }

      const netWorth = calculateNetWorth(player, stocks);
      MILESTONES.forEach((m: Milestone) => {
        if (netWorth >= m.threshold && !player.milestonesHit.has(m.threshold)) {
          player.milestonesHit.add(m.threshold);
          player.coins += m.coins;
          notifications.push(`🏆 MILESTONE: ${m.label} — +${m.coins} coins!`);
        }
      });

      return {
        ...newState,
        day: newState.day + 1,
        player,
        stocks,
        eventLog: [...notifications, ...newState.eventLog].slice(0, 50),
        pendingEvent,
      };
    }
    case 'TOGGLE_PAUSE':
      return { ...state, isPaused: !state.isPaused };
    
    case 'SET_STATE': {
      const loadedState = action.payload;
      if (loadedState.player) {
        if (loadedState.player.businesses && Array.isArray(loadedState.player.businesses)) {
            const seenIds = new Set<string>();
            loadedState.player.businesses.forEach((b: Business) => {
                if (seenIds.has(b.id)) {
                     b.id = `biz_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
                }
                seenIds.add(b.id);
                if (!b.level) {
                  b.level = 1;
                }
            });
        }

        if (loadedState.player.milestonesHit && Array.isArray(loadedState.player.milestonesHit)) {
            loadedState.player.milestonesHit = new Set(loadedState.player.milestonesHit);
        } else if (!loadedState.player.milestonesHit) {
            loadedState.player.milestonesHit = new Set();
        }
        
        if (!loadedState.player.interviewCooldowns) {
          loadedState.player.interviewCooldowns = {};
        }

        if (!loadedState.player.activeBackground) {
          loadedState.player.activeBackground = "";
        }
        if (!loadedState.player.unlockedRewards || !Array.isArray(loadedState.player.unlockedRewards)) {
          loadedState.player.unlockedRewards = [];
        }
        
        if (!loadedState.player.assets) {
          loadedState.player.assets = [];
        }

        if (!loadedState.player.gameMode) {
          loadedState.player.gameMode = 'hard';
        }
        if (loadedState.player.clickPower === undefined) {
          loadedState.player.clickPower = 1;
        }
        if (loadedState.player.clickLevel === undefined) {
          loadedState.player.clickLevel = 1;
        }
      }
      if (!loadedState.modeSaves) {
        loadedState.modeSaves = {};
      }
      return { ...initialState, ...loadedState, lastSpunPrize: null };
    }
        

    case 'BUY_STOCK': {
      const { ticker, quantity } = action.payload;
      const stock = state.stocks[ticker];
      const cost = stock.price * quantity;
      if (cost > state.player.cash) return state;

      return {
        ...state,
        player: {
          ...state.player,
          cash: state.player.cash - cost,
          holdings: {
            ...state.player.holdings,
            [ticker]: (state.player.holdings[ticker] || 0) + quantity,
          },
        },
      };
    }

    case 'SELL_STOCK': {
      const { ticker, quantity } = action.payload;
      const owned = state.player.holdings[ticker] || 0;
      if (quantity > owned) return state;

      const stock = state.stocks[ticker];
      const proceeds = stock.price * quantity;
      
      const newHoldings = { ...state.player.holdings };
      newHoldings[ticker] -= quantity;
      if (newHoldings[ticker] <= 0) {
        delete newHoldings[ticker];
      }

      return {
        ...state,
        player: {
          ...state.player,
          cash: state.player.cash + proceeds,
          holdings: newHoldings,
        },
      };
    }

    case 'START_BUSINESS': {
      const { btype } = action.payload;
      const [startupCost, baseIncome, successChance, , supplyCost] = BUSINESS_TYPES[btype];
      if (state.player.cash < startupCost) return state;

      const newBusiness: Business = {
        id: `biz_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        btype,
        startupCost,
        baseIncome,
        successChance,
        state: 'startup',
        daysRunning: 0,
        totalEarned: 0,
        incomeToday: 0,
        customersToday: 0,
        supplies: 20,
        supplyCost: supplyCost,
        level: 1,
      };

      return {
          ...state,
          player: {
              ...state.player,
              cash: state.player.cash - startupCost,
              businesses: [...state.player.businesses, newBusiness],
          }
      };
    }

    case 'BUY_SUPPLIES': {
        const { businessId, amount } = action.payload;
        const businessIndex = state.player.businesses.findIndex(b => b.id === businessId);
        if (businessIndex === -1) return state;

        const business = state.player.businesses[businessIndex];
        const cost = business.supplyCost * amount;
        if(state.player.cash < cost) return state;
        
        const updatedBusiness = {
            ...business,
            supplies: business.supplies + amount,
            state: business.state === 'stalled' ? 'running' : business.state,
        };

        const newBusinesses = [...state.player.businesses];
        newBusinesses[businessIndex] = updatedBusiness;

        return {
            ...state,
            player: {
                ...state.player,
                cash: state.player.cash - cost,
                businesses: newBusinesses
            }
        };
    }

    case 'UPGRADE_BUSINESS': {
        const { businessId } = action.payload;
        const businessIndex = state.player.businesses.findIndex(b => b.id === businessId);
        if (businessIndex === -1) return state;

        const business = state.player.businesses[businessIndex];
        const currentLevel = business.level;
        
        if (currentLevel >= BUSINESS_UPGRADES.length) return state;

        const nextLevelInfo = BUSINESS_UPGRADES[currentLevel];
        const upgradeCost = nextLevelInfo.costMultiplier * business.startupCost;

        if (state.player.cash < upgradeCost) {
            return state;
        }
        
        const updatedBusiness = {
            ...business,
            level: business.level + 1,
        };

        const newBusinesses = [...state.player.businesses];
        newBusinesses[businessIndex] = updatedBusiness;

        return {
            ...state,
            player: {
                ...state.player,
                cash: state.player.cash - upgradeCost,
                businesses: newBusinesses,
            },
            eventLog: [`💼 SCALE-UP: ${business.btype} is now Level ${updatedBusiness.level}!`, ...state.eventLog].slice(0, 50),
        };
    }

    case 'SET_JOB': {
        const { jobName, cooldown } = action.payload;
        const newCooldowns = cooldown ? {
            ...state.player.interviewCooldowns,
            [state.player.job]: cooldown
        } : state.player.interviewCooldowns;

        return {
            ...state,
            player: {
                ...state.player,
                job: jobName,
                interviewCooldowns: newCooldowns
            }
        };
    }

    case 'UNLOCK_REWARD': {
        const reward = action.payload;
        if (state.player.coins < reward.cost) return state;
        if (state.player.unlockedRewards.includes(reward.name)) return state;

        return {
            ...state,
            player: {
                ...state.player,
                coins: state.player.coins - reward.cost,
                unlockedRewards: [...state.player.unlockedRewards, reward.name],
                activeBackground: (reward.type === 'wallpaper' && reward.value) ? reward.value : state.player.activeBackground,
            }
        };
    }

    case 'BUY_ASSET': {
        const { asset } = action.payload;
        if (state.player.cash < asset.cost) return state;
        if (state.player.assets.some(a => a.name === asset.name)) return state;

        return {
            ...state,
            player: {
                ...state.player,
                cash: state.player.cash - asset.cost,
                assets: [...state.player.assets, asset]
            }
        };
    }

    case 'SET_BACKGROUND': {
      return {
          ...state,
          player: {
              ...state.player,
              activeBackground: action.payload
          }
      };
    }

    case 'ADD_LOG':
      return {
        ...state,
        eventLog: [action.payload, ...state.eventLog].slice(0, 50),
      };

    case 'SPIN_WHEEL': {
      if (state.player.coins < PRIZE_WHEEL_COST) {
        return state;
      }

      let newPlayer = {
        ...state.player,
        coins: state.player.coins - PRIZE_WHEEL_COST,
      };

      const rand = Math.random();
      let cumulativeChance = 0;
      let wonPrize: Prize | null = null;

      const shuffledPrizes = [...PRIZE_WHEEL_REWARDS].sort(() => Math.random() - 0.5);

      for (const prize of shuffledPrizes) {
        cumulativeChance += prize.chance;
        if (rand < cumulativeChance) {
          wonPrize = prize;
          break;
        }
      }
      
      if (!wonPrize) {
        wonPrize = { type: 'nothing', value: null, chance: 1, label: "Nothing" };
      }


      let logMessage = ``;

      if (wonPrize.type === 'coins') {
        newPlayer = {
            ...newPlayer,
            coins: newPlayer.coins + (wonPrize.value as number)
        };
        logMessage = `🎡 PRIZE: You won ${wonPrize.label}!`;
      } else if (wonPrize.type === 'reward') {
        const rewardName = wonPrize.value as string;
        if (!newPlayer.unlockedRewards.includes(rewardName)) {
          const rewardDetails = REWARDS.find(r => r.name === rewardName);
          newPlayer = {
            ...newPlayer,
            unlockedRewards: [...newPlayer.unlockedRewards, rewardName],
            activeBackground: (rewardDetails?.type === 'wallpaper' && rewardDetails.value) ? rewardDetails.value : newPlayer.activeBackground,
          };
          logMessage = `🎡 PRIZE: You won ${wonPrize.label}!`;
        } else {
          logMessage = `🎡 PRIZE: Won ${wonPrize.label}, but already owned it. Received 25 coins instead.`;
          newPlayer = { ...newPlayer, coins: newPlayer.coins + 25 };
        }
      } else if (wonPrize.type === 'nothing') {
        logMessage = `🎡 WHEEL: No prize this time. Better luck next spin!`;
      }
      
      return {
        ...state,
        player: newPlayer,
        lastSpunPrize: wonPrize,
        eventLog: [logMessage, ...state.eventLog].slice(0, 50),
      };
    }
    
    case 'CLEAR_SPIN_RESULT': {
      return { ...state, lastSpunPrize: null };
    }

    case 'SET_GAME_MODE': {
      const newMode = action.payload;
      const oldMode = state.player.gameMode;
      
      if (newMode === oldMode) return state;

      const currentModeData: ModeSave = {
        day: state.day,
        player: state.player,
        stocks: state.stocks,
        eventLog: state.eventLog,
      };
      
      const newModeSaves = {
        ...state.modeSaves,
        [oldMode]: currentModeData,
      };

      const targetSave = newModeSaves[newMode];
      
      if (targetSave) {
        return {
          ...state,
          day: targetSave.day,
          player: { ...targetSave.player, gameMode: newMode },
          stocks: targetSave.stocks,
          eventLog: [`⚙️ MODE: Switched to ${newMode.toUpperCase()}`, ...targetSave.eventLog].slice(0, 50),
          modeSaves: newModeSaves,
        };
      } else {
        return {
          ...state,
          day: 1,
          player: createInitialPlayer(newMode),
          stocks: createInitialStocks(),
          eventLog: [`⚙️ MODE: New ${newMode.toUpperCase()} simulation initialized.`],
          modeSaves: newModeSaves,
        };
      }
    }

    case 'CLICK_MONEY': {
      if (state.player.gameMode !== 'easy') return state;
      return {
        ...state,
        player: {
          ...state.player,
          cash: state.player.cash + state.player.clickPower,
          totalIncomeEarned: state.player.totalIncomeEarned + state.player.clickPower,
        }
      };
    }

    case 'UPGRADE_CLICK': {
      if (state.player.gameMode !== 'easy') return state;
      const upgradeCost = CLICK_UPGRADE_BASE_COST * Math.pow(3.5, state.player.clickLevel - 1);
      if (state.player.cash < upgradeCost) return state;

      return {
        ...state,
        player: {
          ...state.player,
          cash: state.player.cash - upgradeCost,
          clickPower: state.player.clickPower + state.player.clickLevel, 
          clickLevel: state.player.clickLevel + 1,
        },
        eventLog: [`👆 UPGRADE: Clicking power is now Level ${state.player.clickLevel + 1}!`, ...state.eventLog].slice(0, 50),
      };
    }

    case 'RESET_MODE': {
      const currentMode = state.player.gameMode;
      return {
        ...state,
        day: 1,
        player: createInitialPlayer(currentMode),
        stocks: createInitialStocks(),
        eventLog: [`⚠️ RESET: ${currentMode.toUpperCase()} profile cleared.`],
        pendingEvent: null,
      };
    }

    default:
      return state;
  }
}

function OfflineProgressLoader({ days }: { days: number }) {
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center gap-4 text-center p-4">
      <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
      <h2 className="text-2xl font-bold">Processing Operational Data...</h2>
      <p className="text-muted-foreground">Simulating {days} hours of market activity and business operations. Please stand by.</p>
    </div>
  );
}

export const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider = ({ children }: { children: ReactNode }) => {
  const [internalState, dispatch] = useReducer(gameReducer, initialState);
  const [isClient, setIsClient] = useState(false);
  const [isLoaded, setLoaded] = useState(false);
  const [offlineProgress, setOfflineProgress] = useState<{ days: number } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setIsClient(true);
    
    const processGameLoad = async () => {
      let savedStateJSON = null;
      let lastActiveString = null;
      
      if (typeof window !== 'undefined') {
        savedStateJSON = localStorage.getItem('wealthArchitectState');
        lastActiveString = localStorage.getItem('wealthArchitectLastActive');
      }

      if (savedStateJSON && lastActiveString) {
        try {
          const parsedState = JSON.parse(savedStateJSON);
          const lastActiveTime = new Date(lastActiveString).getTime();
          const now = new Date().getTime();
          let hoursPassed = Math.floor((now - lastActiveTime) / (1000 * 60 * 60));
          
          if (parsedState.player && parsedState.player.coins < 6000) {
            parsedState.player.coins = 6000;
          }

          const maxOfflineHours = 720; 
          if (hoursPassed > maxOfflineHours) {
            hoursPassed = maxOfflineHours;
          }

          if (hoursPassed > 0) {
            setOfflineProgress({ days: hoursPassed });
            await new Promise(resolve => setTimeout(resolve, 500)); 
            
            let processedState = parsedState;
            if (processedState.player.milestonesHit && Array.isArray(processedState.player.milestonesHit)) {
                processedState.player.milestonesHit = new Set(processedState.player.milestonesHit);
            }

            const initialNetWorth = calculateNetWorth(processedState.player, processedState.stocks);
            const initialIncome = processedState.player.totalIncomeEarned;
            const initialExpenses = processedState.player.totalExpensesPaid;

            for (let i = 0; i < hoursPassed; i++) {
              processedState = gameReducer(processedState, { type: 'ADVANCE_DAY' });
            }

            const finalNetWorth = calculateNetWorth(processedState.player, processedState.stocks);
            const netChange = finalNetWorth - initialNetWorth;
            const offlineEarned = processedState.player.totalIncomeEarned - initialIncome;
            const offlineSpent = processedState.player.totalExpensesPaid - initialExpenses;

            const summaryMessage = `Yield: +£${offlineEarned.toLocaleString()}\nOperational Costs: -£${offlineSpent.toLocaleString()}\nPortfolio Change: £${netChange > 0 ? '+' : ''}${netChange.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

            toast({
              title: `RE-ENTRY: (${hoursPassed} hours simulated)`,
              description: summaryMessage,
            });

            dispatch({ type: 'SET_STATE', payload: processedState });
          } else {
             dispatch({ type: 'SET_STATE', payload: parsedState });
          }
        } catch (e) {
          console.error("Failed to parse or process saved state", e);
          if (typeof window !== 'undefined') {
            localStorage.removeItem('wealthArchitectState');
            localStorage.removeItem('wealthArchitectLastActive');
          }
        }
      } else if (savedStateJSON) {
        try {
          const parsed = JSON.parse(savedStateJSON);
          if (parsed.player && parsed.player.coins < 6000) {
            parsed.player.coins = 6000;
          }
          dispatch({ type: 'SET_STATE', payload: parsed });
        } catch (e) {
          console.error("Failed to parse saved state", e);
          if (typeof window !== 'undefined') {
            localStorage.removeItem('wealthArchitectState');
          }
        }
      }

      setLoaded(true);
      setOfflineProgress(null);
    };

    processGameLoad();
  }, [toast]); 

  useEffect(() => {
    if (isClient && isLoaded) {
        try {
            const serializableState = {
                ...internalState,
                player: {
                    ...internalState.player,
                    milestonesHit: Array.from(internalState.player.milestonesHit as Set<number>),
                },
                lastSpunPrize: null,
            };
            const stateToSave = JSON.stringify(serializableState);
            const lastActiveDate = new Date();

            localStorage.setItem('wealthArchitectState', stateToSave);
            localStorage.setItem('wealthArchitectLastActive', lastActiveDate.toISOString());
        } catch(e) {
            console.error("Failed to save state", e);
        }
    }
  }, [internalState, isClient, isLoaded]);

  const netWorth = useMemo(() => {
      if (!isLoaded) return 0;
      return calculateNetWorth(internalState.player, internalState.stocks)
    }, [isLoaded, internalState.player, internalState.stocks]);
  
  const state = useMemo(() => ({
    ...internalState,
    netWorth,
  }), [internalState, netWorth]);

  if (!isLoaded) {
    if (offlineProgress) {
        return <OfflineProgressLoader days={offlineProgress.days} />;
    }
    return <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center gap-4 text-center p-4"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div><h2 className="text-2xl font-bold">ACCESSING TERMINAL...</h2></div>;
  }
  
   if (offlineProgress) {
      return <OfflineProgressLoader days={offlineProgress.days} />;
  }

  const value = { state, dispatch };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
};
